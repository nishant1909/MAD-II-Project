# from application import create_app
from flask import Flask
from flask_cors import CORS 
from backend.model import db
from backend import config
from flask_jwt_extended import JWTManager
from flask_mail import Mail
from flask_caching import Cache
from backend.redis_celery.celery_config import celery_init_app
import flask_excel as excel
import backend.redis_celery.celerybeat_schedule

# Extensions
jwt = JWTManager()
mail = Mail()
cache = Cache()

def create_app():
    app = Flask(__name__)
    app.config.from_object(config.Config)
    # Enable CORS
    CORS(app, resources={r"/*": {"origins": "http://localhost:8080"}}, supports_credentials=True)

    # Initialize extensions
    db.init_app(app)
    jwt.init_app(app)
    mail.init_app(app)
    cache.init_app(app)
    
    # Make cache available to blueprints
    from backend.routes.user_routes import cache_instance as user_cache
    user_cache.init_app(app)
    
    from backend.routes.admin_routes import cache_instance as admin_cache
    admin_cache.init_app(app)
    
    from backend.routes.routes import cache_instance as routes_cache
    routes_cache.init_app(app)
    
    # Register blueprints
    from backend.routes.routes import routes_bp
    from backend.routes.admin_routes import admin_bp
    from backend.routes.user_routes import user_bp
    
    app.register_blueprint(routes_bp, url_prefix='/')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    app.register_blueprint(user_bp, url_prefix='/user')

    return app

app = create_app()

celery_app = celery_init_app(app)

if __name__ == '__main__':
    excel.init_excel(app)
    app.run(debug=True)