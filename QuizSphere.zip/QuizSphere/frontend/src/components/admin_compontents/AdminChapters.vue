<template>
    <div class="admin-chapters-page">
        <h2>Chapters for Subject: {{ subject_name }}</h2>

        <!-- Search Add Chapter container -->
        <div class="search-add-container d-flex mb-3">
            <!-- Search Box -->
            <div class="search-box">
                <input type="text" v-model="searchQuery" @input="searchChapters" placeholder="Search chapters..."
                    class="form-control" />
            </div>

            <!-- Add New Chapter Button -->
            <button class="btn btn-primary add-chapter-btn" data-bs-toggle="modal" data-bs-target="#addChapterModal">
                &#43; Add New Chapter
            </button>
        </div>

        <div class="modal fade" id="addChapterModal" tabindex="-1" aria-labelledby="addChapterModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title ms-1" id="addChapterModalLabel">Add New Chapter</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-floating mb-3 mx-2">
                            <input v-model="newChapter.chapter_name" type="text" class="form-control" required
                                id="chapterName" placeholder="Enter chapter name" />
                            <label for="chapterName" class="form-label">Chapter Name</label>
                        </div>
                        <div class="form-floating mb-3 mx-2">
                            <textarea v-model="newChapter.chapter_description" class="form-control"
                                id="chapterDescription" rows="3" placeholder="Enter chapter description"
                                required></textarea>
                            <label for="chapterDescription" class="form-label">Chapter Description</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                            ref="cancelButtonChapter">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="addChapter">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <div v-if="chapters.length === 0">
            No chapters added yet!
        </div>
        <div class="grid">
            <div v-for="chapter in filteredChapters" :key="chapter.chapter_id" class="card">
                <div class="img">
                    <img src="../../assets/logo.png" class="logo">
                    <img src="../../assets/chapter.jpg" class="chapter">
                </div>
                <div class="card-body text-start ms-2">
                    <h4 class="card-title">{{ chapter.chapter_name }} </h4>
                    <p class="card-text">{{ chapter.chapter_description }} </p>

                    <div class="button-column">
                        <router-link :to="{ path: `${$route.path}/${chapter.chapter_id}/quizzes` }"
                            class="btn btn-info me-2" title="View Quizzes">View
                            Quizzes</router-link>

                        <button data-bs-toggle="modal" data-bs-target="#editChapterModal"
                            class="btn btn-warning me-2 edit" @click="assignChapter(chapter)" title="Edit Chapter">
                            <i class="fa fa-edit"></i>
                        </button>

                        <!-- Edit Chapter Modal -->
                        <div class="modal fade" id="editChapterModal" tabindex="-1"
                            aria-labelledby="editChapterModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title ms-1" id="editChapterModalLabel">Edit Chapter
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-floating mb-3 mx-2">
                                            <input v-model="editChapterData.chapter_name" type="text"
                                                class="form-control" id="editChapterName"
                                                placeholder="Enter chapter name" required />
                                            <label for="editChapterName" class="form-label">Chapter Name</label>
                                        </div>
                                        <div class="form-floating mb-3 ms-2">
                                            <textarea v-model="editChapterData.chapter_description" class="form-control"
                                                id="editChapterDescription" rows="3"
                                                placeholder="Enter chapter description" required></textarea>
                                            <label for="editChapterDescription" class="form-label">Chapter
                                                Description</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                            id="cancelEditChapter" ref="cancelEditChapter">
                                            Cancel
                                        </button>

                                        <button type="button" class="btn btn-primary" @click="updateChapter">Save
                                            Changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Toggle chapter data -->
                        <button :class="['btn', chapter.chapter_status === 'Active' ? 'btn-success' : 'btn-danger']"
                            @click="toggleChapterStatus(chapter)"
                            :title="chapter.chapter_status === 'Active' ? 'Click to Deactivate' : 'Click to Activate'">
                            <i
                                :class="chapter.chapter_status === 'Active' ? 'fa fa-toggle-on' : 'fa fa-toggle-off'"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ["subject_id"],
    data() {
        return {
            subject_name: "",
            searchQuery: "",
            chapters: [],
            filteredChapters: [],
            newChapter: { chapter_name: "", chapter_description: "" },
            editChapterData: { chapter_id: null, chapter_name: "", chapter_description: "" },

        };
    },
    mounted() {
        this.fetchChapters();
    },
    methods: {
        async fetchChapters() {
            try {
                const response = await fetch(
                    `http://127.0.0.1:5000/admin/home/subject/${this.subject_id}/chapters`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${localStorage.getItem("token")}`,
                        },
                    }
                );
                if (response.ok) {
                    const data = await response.json();
                    this.subject_name = data.subject_name;
                    this.chapters = data.chapters || [];
                    this.filteredChapters = this.chapters;
                    console.log(this.chapters)
                } else {
                    const errorData = await response.json();
                    alert("Failed to fetch chapters: " + errorData.message);
                }
            } catch (error) {
                console.error("Error fetching chapters:", error);
            }
        },

        searchChapters() {
            const query = this.searchQuery.toLowerCase();
            this.filteredChapters = this.chapters.filter(chapter =>
                chapter.chapter_name.toLowerCase().includes(query) || chapter.chapter_description.toLowerCase().includes(query)
            );
        },

        async addChapter() {
            if (!this.newChapter.chapter_name.trim() || !this.newChapter.chapter_description.trim()) {
                alert("Please fill out both the chapter name and description.");
                return;
            }
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/subject/${this.subject_id}/add/chapter`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        name: this.newChapter.chapter_name,
                        description: this.newChapter.chapter_description,
                    }),
                });
                if (response.ok) {
                    alert("Chapter added successfully");
                    this.fetchChapters();
                    this.newChapter = { chapter_name: "", chapter_description: "" };
                    this.$refs.cancelButtonChapter.click();
                } else {
                    alert("Failed to add chapter");
                }
            } catch (error) {
                console.error("Error adding chapter:", error);
            }
        },



        assignChapter(chapter) {
            this.editChapterData = {
                chapter_id: chapter.chapter_id,
                chapter_name: chapter.chapter_name,
                chapter_description: chapter.chapter_description,
            };
        },

        async updateChapter() {
            const { chapter_id, chapter_name, chapter_description } = this.editChapterData;

            if (!chapter_name.trim() || !chapter_description.trim()) {
                alert("Please fill out both the chapter name and description.");
                return;
            }

            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/chapters/${chapter_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        name: chapter_name,
                        description: chapter_description,
                    }),
                });

                if (response.ok) {
                    alert("Chapter updated successfully");
                    this.fetchChapters();
                    document.getElementById("cancelEditChapter").click();

                } else {
                    const errorData = await response.json();
                    alert("Failed to update chapter: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating chapter:", error);
            }
        },

        async toggleChapterStatus(chapter) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/toggle/chapter/${chapter.chapter_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    chapter.chapter_status = data.status;
                    this.fetchChapters();
                } else {
                    const errorData = await response.json();
                    alert("Failed to toggle status: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error toggling chapter status:", error);
            }
        },


    },
};
</script>

<style scoped>
.admin-chapters-page {
    padding: 20px;
}

.search-box {
    width: 85%;
}

.search-box input {
    margin-top: 3px;
    width: 95%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.add-chapter-btn {
    width: 15%;
    padding: 10px;
    border-radius: 5px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

.chapter {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 1%;
    border-top-right-radius: 1%;
}

.edit {
    color: white;
}
</style>
