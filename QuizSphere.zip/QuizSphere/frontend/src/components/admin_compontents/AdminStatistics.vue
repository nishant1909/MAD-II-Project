<template>
    <div class="admin-dashboard container mt-4">
        <h2 class="text-center text-primary">Admin Dashboard - Statistics</h2>

        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Users</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_users }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Active Users</h5>
                    <h3 class="text-center text-primary">{{ statistics.active_users }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Blocked Users</h5>
                    <h3 class="text-center text-primary">{{ statistics.blocked_users }}</h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Subjects</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_subjects }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Chapters</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_chapters }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Quizzes</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_quizzes }}</h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Subjects Attempted</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_subjects_attempted }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Chapters Attempted</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_chapters_attempted }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Quiz Attempts</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_quizzes_attempted }}</h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Active Subjects</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_active_subjects }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Active Chapters</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_active_chapters }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Active Quizzes</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_active_quizzes }}</h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Inactive Subjects</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_inactive_subjects }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Inactive Chapters</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_inactive_chapters }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Inactive Quizzes</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_inactive_quizzes }}</h3>
                </div>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Different Users Attempted</h5>
                    <h3 class="text-center text-primary">{{ statistics.different_users_attempted }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Quizzes Have Question</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_quizzes_have_question }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Quizzes Have No Question</h5>
                    <h3 class="text-center text-primary">{{ statistics.total_quizzes_have_no_question }}</h3>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            statistics: {
                total_users: 0,
                active_users: 0,
                blocked_users: 0,
                total_subjects: 0,
                total_subjects_attempted: 0,
                total_chapters: 0,
                total_chapters_attempted: 0,
                total_quizzes: 0,
                total_quizzes_attempted: 0,
                different_users_attempted: 0,
                total_active_subjects: 0,
                total_inactive_subjects: 0,
                total_active_chapters: 0,
                total_inactive_chapters: 0,
                total_active_quizzes: 0,
                total_inactive_quizzes: 0,
                total_quizzes_have_question: 0,
                total_quizzes_have_no_question: 0
            }
        };
    },
    mounted() {
        this.fetchAdminStatistics();
    },
    methods: {
        async fetchAdminStatistics() {
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/statistics", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    this.statistics = data;
                    console.log(this.statistics);
                } else {
                    console.error("Failed to fetch admin statistics.");
                }
            } catch (error) {
                console.error("Error fetching admin statistics:", error);
            }
        }
    }
};
</script>


<style scoped>
.admin-dashboard {
    font-family: Arial, sans-serif;
    padding: 20px;
}
</style>