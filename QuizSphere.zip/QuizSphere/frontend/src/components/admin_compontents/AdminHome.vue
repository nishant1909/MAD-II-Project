<template>
    <div class="admin-home-page">
        <main>
            <h2>Admin Dashboard</h2>

            <!-- Box 1: Subjects grid -->
            <div class="box">
                <h3 class="fw-bold">Subjects</h3>
                <div class="d-flex mb-2">
                    <div class="search-box">
                        <input type="text" v-model="searchQuerySubject" @input="searchSubjects"
                            placeholder="Search subjects..." class="form-control" />
                    </div>
                    <div class="btn-box">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addSubjectModal"
                            title="Add New Subject">
                            &#43; Add New Subject
                        </button>
                        <router-link :to="{ path: `${$route.path}/subjects` }" class="button"
                            title="View All Subjects">View
                            All
                            Subjects</router-link>
                    </div>
                </div>


                <div v-if="subjects.length === 0" class="text-center">
                    No subjects available
                </div>
                <div v-if="filteredSubjects.length === 0" class="text-center">
                    No Subject with this Query!
                </div>
                <div class="grid">
                    <div v-for="subject in filteredSubjects.slice(0, 6)" :key="subject.subject_id" class="card">
                        <div class="img">
                            <img src="../../assets/logo.png" class="logo">
                            <img src="../../assets/subject.jpg" class="subject">
                        </div>
                        <div class="card-body text-start ms-2">
                            <h4 class="card-title">{{ subject.subject_name }}</h4>
                            <p class="card-text">{{ subject.subject_description }}</p>

                            <div class="button-column">
                                <router-link :to="{ path: `${$route.path}/subjects/${subject.subject_id}/chapters` }"
                                    class="btn btn-info me-2" title="View Chapters">View
                                    Chapters</router-link>

                                <button data-bs-toggle="modal" data-bs-target="#editSubjectModal"
                                    class="btn btn-warning me-2" @click="assignSubject(subject)" title="Edit Subject">
                                    <i class="fa fa-edit"></i>
                                </button>

                                <!-- Edit Subject Modal -->
                                <div class="modal fade" id="editSubjectModal" tabindex="-1"
                                    aria-labelledby="editSubjectModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title ms-1" id="editSubjectModalLabel">Edit Subject
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-floating mb-3 mx-2">
                                                    <input v-model="editSubjectData.subject_name" type="text"
                                                        class="form-control" id="editSubjectName"
                                                        placeholder="Enter subject name" required />
                                                    <label for="editSubjectName" class="form-label">Subject Name</label>
                                                </div>
                                                <div class="form-floating mb-3 ms-2">
                                                    <textarea v-model="editSubjectData.subject_description"
                                                        class="form-control" id="editSubjectDescription" rows="3"
                                                        placeholder="Enter subject description" required></textarea>
                                                    <label for="editSubjectDescription" class="form-label">Subject
                                                        Description</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                                    id="cancelEditSubject" ref="cancelEditSubject">
                                                    Cancel
                                                </button>

                                                <button type="button" class="btn btn-primary"
                                                    @click="updateSubject">Save Changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Toggle subject data -->
                                <button
                                    :class="['btn', subject.subject_status === 'Active' ? 'btn-success' : 'btn-danger']"
                                    @click="toggleSubjectStatus(subject)"
                                    :title="subject.subject_status === 'Active' ? 'Click to Deactivate' : 'Click to Activate'">
                                    <i
                                        :class="subject.subject_status === 'Active' ? 'fa fa-toggle-on' : 'fa fa-toggle-off'"></i>
                                </button>


                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Add subject modal -->
            <div class="modal fade" id="addSubjectModal" tabindex="-1" aria-labelledby="addSubjectModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title ms-1" id="addSubjectModalLabel">Add New Subject</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newSubject.subject_name" type="text" class="form-control" required
                                    id="subjectName" placeholder="Enter subject name" />
                                <label for="subjectName" class="form-label">Subject Name</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <textarea v-model="newSubject.subject_description" class="form-control"
                                    id="subjectDescription" rows="3" placeholder="Enter subject description"
                                    required></textarea>
                                <label for="subjectDescription" class="form-label">Subject Description</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                ref="cancelButtonSubject">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="addSubject">Save</button>
                        </div>
                    </div>
                </div>
            </div>



            <!-- Box 2: Quizzes grid -->
            <div class="box">
                <h3 class="fw-bold">Quizzes</h3>
                <div class="d-flex mb-2">
                    <div class="search-box">
                        <input type="text" v-model="searchQueryQuiz" @input="searchQuizzes"
                            placeholder="Search quizzes..." class="form-control" />
                    </div>
                    <div class="btn-box">
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addQuizModal"
                            title="Add New Quiz">
                            &#43; Add New Quiz
                        </button>
                        <router-link :to="{ path: `${$route.path}/quizzes` }" class="button"
                            title="View All Quizzes">View
                            All Quizzes</router-link>
                    </div>
                </div>

                <div v-if="quizzes.length === 0" class="text-center">
                    No quizzes available
                </div>
                <div v-if="filteredQuizzes.length === 0">
                    No Quiz with this Query!
                </div>
                <div class="grid">
                    <div v-for="quiz in filteredQuizzes.slice(0, 6)" :key="quiz.quiz_id" class="card">
                        <div class="img">
                            <img src="../../assets/logo.png" class="logo">
                            <img src="../../assets/quiz.avif" class="quiz">
                        </div>
                        <div class="card-body text-start ms-2">
                            <h4 class="card-title">{{ quiz.quiz_name }}</h4>
                            <p class="card-text"><strong>Subject: </strong> {{ quiz.subject_name }}</p>
                            <p class="card-text"><strong>Chapter: </strong> {{ quiz.chapter_name }}</p>
                            <p class="card-text"><strong>Remarks: </strong> {{ quiz.remarks ||
                                'No Remarks' }}</p>
                            <p class="card-text"><strong>Schedule: </strong> <span v-if="quiz.quiz_schedule">Attempt
                                    after {{ formatDateTime(quiz.quiz_schedule) }}</span>
                                <span v-else>Attempt Anytime</span>
                            </p>
                            <p class="card-text"><strong>Time Duration: </strong> {{
                                quiz.time_duration === 'No Time Limit' ? 'No Time Limit' :
                                    quiz.time_duration + ' min' }}</p>

                            <div class="button-column">
                                <router-link
                                    :to="{ path: `${$route.path}/subjects/${quiz.subject_id}/chapters/${quiz.chapter_id}/quizzes/${quiz.quiz_id}` }"
                                    class="btn btn-info me-2" title="View Quiz">View
                                    Quiz</router-link>

                                <button data-bs-toggle="modal" data-bs-target="#editQuizModal"
                                    class="btn btn-warning me-2 edit" @click="assignQuiz(quiz)" title="Edit QUiz">
                                    <i class="fa fa-edit"></i>
                                </button>

                                <!-- Edit Quiz Modal -->
                                <div class="modal fade" id="editQuizModal" tabindex="-1"
                                    aria-labelledby="editQuizModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title ms-1" id="editQuizModalLabel">Edit Quiz
                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-floating mb-3 mx-2">
                                                    <input v-model="editQuizData.quiz_name" type="text"
                                                        class="form-control" id="editQuizName"
                                                        placeholder="Enter quiz name" required>
                                                    <label for="editQuizName" class="form-label">Quiz Name</label>
                                                </div>
                                                <div class="form-floating mb-3 mx-2">
                                                    <input v-model="editQuizData.remarks" type="text"
                                                        class="form-control" id="quizRemarks"
                                                        placeholder="Enter remarks" />
                                                    <label for="quizRemarks" class="form-label">Remarks</label>
                                                </div>
                                                <div class="form-floating mb-3 mx-2">
                                                    <input v-model="editQuizData.quiz_schedule" type="datetime-local"
                                                        class="form-control" id="quizSchedule"
                                                        placeholder="Enter quiz schedule" :min="minDate" />
                                                    <label for="quizSchedule" class="form-label">Quiz Schedule</label>
                                                </div>
                                                <div class="form-floating mb-3 mx-2">
                                                    <input v-model="editQuizData.time_duration" type="time"
                                                        class="form-control" id="quizDuration"
                                                        placeholder="Enter duration in HH:MM" />
                                                    <label for="quizDuration" class="form-label">Time Duration
                                                        (HH:MM)</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                                    ref="cancelEditQuiz" id="cancelEditQuiz">Cancel</button>
                                                <button type="button" class="btn btn-primary" @click="updateQuiz">Save
                                                    Changes</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Toggle quiz data -->
                                <button :class="['btn', quiz.quiz_status === 'Active' ? 'btn-success' : 'btn-danger']"
                                    @click="toggleQuizStatus(quiz)"
                                    :title="quiz.quiz_status === 'Active' ? 'Click to Deactivate' : 'Click to Activate'">
                                    <i
                                        :class="quiz.quiz_status === 'Active' ? 'fa fa-toggle-on' : 'fa fa-toggle-off'"></i>
                                </button>

                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Add quiz modal -->
            <div class="modal fade" id="addQuizModal" tabindex="-1" aria-labelledby="addQuizModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addQuizModalLabel">Add New Quiz</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-floating mb-3 mx-2">
                                <select v-model="newQuiz.subject_id" class="form-select" id="quizSubject"
                                    @change="fetchChaptersForSubject">
                                    <option v-if="subjects.length === 0" disabled>No Subject available</option>
                                    <option v-else v-for="subject in subjects" :key="subject.subject_id"
                                        :value="subject.subject_id">
                                        {{ subject.subject_name }}
                                    </option>
                                </select>
                                <label for="quizSubject" class="form-label">Select Subject</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <select v-model="newQuiz.chapter_id" class="form-select" id="quizChapter">
                                    <option v-if="chapters.length === 0" disabled>No chapter available for selected
                                        subject.</option>
                                    <option v-else v-for="chapter in chapters" :key="chapter.chapter_id"
                                        :value="chapter.chapter_id">
                                        {{ chapter.chapter_name }}
                                    </option>
                                </select>
                                <label for="quizChapter" class="form-label">Select Chapter</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.quiz_name" type="text" class="form-control" id="quizName"
                                    placeholder="Enter quiz name" />
                                <label for="quizName" class="form-label">Quiz Name</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.remarks" type="text" class="form-control" id="quizRemarks"
                                    placeholder="Enter remarks" />
                                <label for="quizRemarks" class="form-label">Remarks</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.quiz_schedule" type="datetime-local" class="form-control"
                                    id="quizSchedule" placeholder="Enter quiz schedule" :min="minDate" />
                                <label for="quizSchedule" class="form-label">Quiz Schedule</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.time_duration" type="time" class="form-control"
                                    id="quizDuration" placeholder="Enter duration in HH:MM" />
                                <label for="quizDuration" class="form-label">Time Duration (HH:MM)</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                ref="cancelButtonQuiz">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="addQuiz">Save</button>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</template>

<script>
export default {
    data() {
        return {
            subjects: [],
            searchQuerySubject: "",
            filteredSubjects: [],
            quizzes: [],
            searchQueryQuiz: "",
            filteredQuizzes: [],
            chapters: [],
            newSubject: { subject_name: "", subject_description: "" },
            editSubjectData: { subject_id: null, subject_name: "", subject_description: "" },
            newQuiz: { subject_id: null, chapter_id: null, quiz_name: "", quiz_schedule: null, time_duration: null, remarks: "" },
            editQuizData: { quiz_id: null, quiz_name: "", quiz_schedule: null, time_duration: null, remarks: "" },
            minDate: new Date(new Date().getTime()).toISOString().slice(0, 16),
        };
    },
    methods: {
        async fetchHome() {
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/home", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.subjects = data.subjects || [];
                    this.filteredSubjects = this.subjects;
                    this.quizzes = data.quizzes || [];
                    this.filteredQuizzes = this.quizzes;
                } else {
                    const errorData = await response.json();
                    console.error("Failed to fetch data", errorData.msg);
                    alert("Error: " + errorData.msg);
                }
            } catch (error) {
                console.error("Error in fetching:", error);
            }
        },

        searchSubjects() {
            const query = this.searchQuerySubject.toLowerCase();
            this.filteredSubjects = this.subjects.filter(subject =>
                subject.subject_name.toLowerCase().includes(query) || subject.subject_description.toLowerCase().includes(query)
            );
        },

        async addSubject() {
            if (!this.newSubject.subject_name.trim() || !this.newSubject.subject_description.trim()) {
                alert("Please fill out both the subject name and description.");
                return;
            }
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/add/subject", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        name: this.newSubject.subject_name,
                        description: this.newSubject.subject_description,
                    }),
                });
                if (response.ok) {
                    alert("Subject added successfully");
                    this.fetchHome();
                    this.newSubject = { subject_name: "", subject_description: "" };
                    console.error(this.$refs.cancelButtonSubject.click())
                    this.$refs.cancelButtonSubject.click();
                } else {
                    alert("Failed to add subject");
                }
            } catch (error) {
                console.error("Error adding subject:", error);
            }
        },


        assignSubject(subject) {
            this.editSubjectData = {
                subject_id: subject.subject_id,
                subject_name: subject.subject_name,
                subject_description: subject.subject_description,
            };
        },

        async updateSubject() {
            const { subject_id, subject_name, subject_description } = this.editSubjectData;

            if (!subject_name.trim() || !subject_description.trim()) {
                alert("Please fill out both the subject name and description.");
                return;
            }

            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/subjects/${subject_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        name: subject_name,
                        description: subject_description,
                    }),
                });

                if (response.ok) {
                    alert("Subject updated successfully");
                    this.fetchHome(); // Refresh the subject list
                    document.getElementById("cancelEditSubject").click();

                } else {
                    const errorData = await response.json();
                    alert("Failed to update subject: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating subject:", error);
            }
        },

        async toggleSubjectStatus(subject) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/toggle/subject/${subject.subject_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    // alert(data.message);
                    subject.subject_status = data.status;
                    this.fetchHome();
                } else {
                    const errorData = await response.json();
                    alert("Failed to toggle status: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error toggling subject status:", error);
            }
        },

        searchQuizzes() {
            const query = this.searchQueryQuiz.toLowerCase();

            this.filteredQuizzes = this.quizzes.filter(quiz => {
                const scheduleStatus = quiz.quiz_schedule ? `attempt after ${this.formatDateTime(quiz.quiz_schedule)}` : "attempt anytime";
                return ((quiz.quiz_name?.toLowerCase() || "").includes(query) ||
                    (quiz.remarks?.toLowerCase() || "").includes(query) ||
                    (quiz.time_duration?.toLowerCase() || "").includes(query) ||
                    scheduleStatus.includes(query)
                );
            });
        },



        async fetchChaptersForSubject() {
            const subject_id = this.newQuiz.subject_id;
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/home/subject/${subject_id}/chapters`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.chapters = data.chapters || [];
                    console.warn(data)
                    console.warn(this.chapters)
                } else {
                    alert("Failed to fetch chapters for the selected subject");
                }
            } catch (error) {
                console.error("Error fetching chapters:", error);
            }
        },


        async addQuiz() {
            if (!this.newQuiz.chapter_id) {
                alert("Please select a chapter.");
                return;
            }
            if (!this.newQuiz.quiz_name.trim()) {
                alert("Please enter a quiz name.");
                return;
            }


            try {
                const response = await fetch("http://127.0.0.1:5000/admin/add/quiz", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        chapter_id: this.newQuiz.chapter_id,
                        quiz_name: this.newQuiz.quiz_name,
                        quiz_schedule: this.newQuiz.quiz_schedule,
                        time_duration: this.newQuiz.time_duration,
                        remarks: this.newQuiz.remarks,
                    }),
                });
                if (response.ok) {
                    alert("Quiz added successfully");
                    this.fetchHome();
                    this.newQuiz = { subject_id: null, quiz_name: "", time_duration: null };
                    this.$refs.cancelButtonQuiz.click();
                } else {
                    const errorData = await response.json();
                    alert("Failed to add quiz: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error adding quiz:", error);
            }
        },

        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },

        convertToHHMM(totalMinutes) {
            const hours = Math.floor(totalMinutes / 60);
            const minutes = totalMinutes % 60;

            const formattedHours = String(hours).padStart(2, '0');
            const formattedMinutes = String(minutes).padStart(2, '0');

            return `${formattedHours}:${formattedMinutes}`;
        },

        assignQuiz(quiz) {
            let duration;

            if (quiz.time_duration === "No Time Limit") {
                duration = "00:00";
            } else {
                duration = this.convertToHHMM(quiz.time_duration);
            }

            this.editQuizData = {
                quiz_id: quiz.quiz_id,
                quiz_name: quiz.quiz_name,
                quiz_schedule: quiz.quiz_schedule,
                time_duration: duration,
                remarks: quiz.remarks,
            };
        },

        async updateQuiz() {
            const { quiz_id, quiz_name, quiz_schedule, time_duration, remarks } = this.editQuizData;

            if (!quiz_name.trim()) {
                alert("Please enter a quiz name.");
                return;
            }

            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/quizzes/${quiz_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        quiz_name: quiz_name,
                        quiz_schedule: quiz_schedule,
                        time_duration: time_duration,
                        remarks: remarks,
                    }),
                });

                if (response.ok) {
                    alert("Quiz updated successfully");
                    this.fetchHome();
                    document.getElementById("cancelEditQuiz").click();

                } else {
                    const errorData = await response.json();
                    alert("Failed to update quiz: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating quiz:", error);
            }
        },

        async toggleQuizStatus(quiz) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/toggle/quiz/${quiz.quiz_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    quiz.quiz_status = data.status;
                    this.fetchHome();
                } else {
                    const errorData = await response.json();
                    alert("Failed to toggle status: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error toggling subject status:", error);
            }
        },



        logout() {
            localStorage.removeItem("token");
            this.$router.push("/login");
        },
    },

    mounted() {
        this.fetchHome();
    }

};
</script>

<style scoped>
.admin-home-page {
    font-family: Arial, sans-serif;
    padding: 20px;
}

h2 {
    color: #007bff;
    margin-bottom: 20px;
}


.box {
    margin: 20px 0;
    padding: 20px;
    background: #f8f9fa;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.box h3 {
    margin-bottom: 10px;
    display: inline-block;
}

.search-box {
    width: 65%;
}

.search-box input {
    margin-top: 3px;
    width: 95%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.btn-box {
    width: 35%;
    margin-bottom: 10px;
    display: flex;
    justify-content: end;
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.subject {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.quiz {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

button {
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 10px;
}

.button {
    background: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 10px;
    text-decoration: none;
}

.btn-close {
    text-emphasis-color: black;
    background: none;
}

.edit {
    color: white;
}
</style>
