<template>
    <div class="admin-leaderboard">
        <h2 class="text-center">Admin Leaderboard</h2>

        <div v-if="leaderboard.length === 0" class="alert alert-warning text-center">
            No data available.
        </div>

        <table v-else class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>User</th>
                    <th>Email ID</th>
                    <th>No. of Distinct Quiz Attempted</th>
                    <th>Total Score</th>
                    <th>Average</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(user, index) in leaderboard" :key="user.user_id">
                    <td>{{ index + 1 }}</td>
                    <td>{{ user.full_name }}</td>
                    <td>{{ user.email }}</td>
                    <td>{{ user.totalDistinctQuiz }}</td>
                    <td>{{ user.totalScore }}</td>
                    <td>{{ user.average }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
export default {
    data() {
        return {
            users: [],
            scores: [],
            leaderboard: []
        };
    },
    mounted() {
        this.fetchUsersScores();
    },
    methods: {
        async fetchUsersScores() {
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/leaderboard", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`
                    }
                });

                if (response.ok) {
                    const data = await response.json();
                    this.users = data.users || [];
                    this.scores = data.scores || [];
                    this.createLeaderboard();
                } else {
                    const errorData = await response.json();
                    console.error("Failed to fetch:", errorData.error);
                    alert("Error: " + errorData.error);
                }
            } catch (error) {
                console.error("Error in fetching:", error);
            }
        },

        createLeaderboard() {
            const userScores = {};

            // Process scores to track highest score per quiz for each user
            this.scores.forEach(({ user_id, quiz_id, total_scored }) => {
                if (!userScores[user_id]) {
                    userScores[user_id] = { distinctQuizzes: new Set(), quizScores: {} };
                }

                // Add quiz to distinct quiz set
                userScores[user_id].distinctQuizzes.add(quiz_id);

                // Store the highest score for each quiz
                if (!userScores[user_id].quizScores[quiz_id] || userScores[user_id].quizScores[quiz_id] < total_scored) {
                    userScores[user_id].quizScores[quiz_id] = total_scored;
                }
            });

            // Build leaderboard
            this.leaderboard = Object.keys(userScores).map(user_id => {
                const user = userScores[user_id];
                const totalDistinctQuiz = user.distinctQuizzes.size;
                const totalScore = Object.values(user.quizScores).reduce((a, b) => a + b, 0);
                const userInfo = this.users.find(u => u.user_id === parseInt(user_id));
                const average = Math.round((totalScore / totalDistinctQuiz) * 1000) / 1000;

                return {
                    user_id: user_id,
                    full_name: userInfo ? userInfo.full_name : "Unknown User",
                    email: userInfo ? userInfo.email : "Unknown Email",
                    totalDistinctQuiz,
                    totalScore,
                    average,
                };
            });

            // Sort leaderboard by total score (descending), then by distinct quiz count (descending)
            this.leaderboard.sort((a, b) => {
                if (b.totalScore === a.totalScore) {
                    return a.totalDistinctQuiz - b.totalDistinctQuiz;
                }
                return b.average - a.average;
            });
        },
    }
};
</script>

<style scoped>
.admin-leaderboard {
    padding: 20px;
}

.table {
    margin-top: 20px;
}

.table th,
.table td {
    text-align: center;
}

.alert {
    margin-top: 20px;
}
</style>
