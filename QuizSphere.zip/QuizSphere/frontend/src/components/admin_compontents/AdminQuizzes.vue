<template>
    <div class="admin-quizzes">
        <h2 class="">All Quizzes</h2>

        <!-- Search Add Quiz container -->
        <div class="d-flex mb-3">
            <!-- Search Box -->
            <div class="search-box">
                <input type="text" v-model="searchQuery" @input="searchQuizzes" placeholder="Search quizzes..."
                    class="form-control" />
            </div>

            <!-- Add New Quiz Button -->
            <button class="btn btn-primary add-quiz-btn" data-bs-toggle="modal" data-bs-target="#addQuizModal">
                &#43; Add New Quiz
            </button>

            <div class="modal fade" id="addQuizModal" tabindex="-1" aria-labelledby="addQuizModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="addQuizModalLabel">Add New Quiz</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="form-floating mb-3 mx-2">
                                <select v-model="newQuiz.subject_id" class="form-select" id="quizSubject"
                                    @change="fetchChaptersForSubject">
                                    <option v-if="subjects.length === 0" disabled>No Subject available</option>
                                    <option v-else v-for="subject in subjects" :key="subject.subject_id"
                                        :value="subject.subject_id">
                                        {{ subject.subject_name }}
                                    </option>
                                </select>
                                <label for="quizSubject" class="form-label">Select Subject</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <select v-model="newQuiz.chapter_id" class="form-select" id="quizChapter">
                                    <option v-if="chapters.length === 0" disabled>No chapter available for selected
                                        subject.</option>
                                    <option v-else v-for="chapter in chapters" :key="chapter.chapter_id"
                                        :value="chapter.chapter_id">
                                        {{ chapter.chapter_name }}
                                    </option>
                                </select>
                                <label for="quizChapter" class="form-label">Select Chapter</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.quiz_name" type="text" class="form-control" id="quizName"
                                    placeholder="Enter quiz name" />
                                <label for="quizName" class="form-label">Quiz Name</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.remarks" type="text" class="form-control" id="quizRemarks"
                                    placeholder="Enter remarks" />
                                <label for="quizRemarks" class="form-label">Remarks</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.quiz_schedule" type="datetime-local" class="form-control"
                                    id="quizSchedule" placeholder="Enter quiz schedule" :min="minDate" />
                                <label for="quizSchedule" class="form-label">Quiz Schedule</label>
                            </div>
                            <div class="form-floating mb-3 mx-2">
                                <input v-model="newQuiz.time_duration" type="time" class="form-control"
                                    id="quizDuration" placeholder="Enter duration in HH:MM" />
                                <label for="quizDuration" class="form-label">Time Duration (HH:MM)</label>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                ref="cancelButtonQuiz">Cancel</button>
                            <button type="button" class="btn btn-primary" @click="addQuiz">Save</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div v-if="quizzes.length === 0">
            No Quiz added yet!
        </div>
        <div v-if="filteredQuizzes.length === 0">
            No Quiz with this Query!
        </div>
        <div class="grid">
            <div v-for="quiz in filteredQuizzes" :key="quiz.quiz_id" class="card">
                <div class="img">
                    <img src="../../assets/logo.png" class="logo">
                    <img src="../../assets/quiz.avif" class="quiz">
                </div>
                <div class="card-body text-start ms-2">
                    <h4 class="card-title">{{ quiz.quiz_name }}</h4>
                    <p class="card-text"><strong>Remarks: </strong> {{
                        quiz.remarks }}</p>
                    <p class="card-text"><strong>Schedule: </strong> <span v-if="quiz.quiz_schedule">Attempt
                            after {{ formatDateTime(quiz.quiz_schedule) }}</span>
                        <span v-else>Attempt Anytime</span>
                    </p>
                    <p class="card-text"><strong>Time Duration: </strong> {{
                        quiz.time_duration === 'No Time Limit' ? 'No Time Limit' : quiz.time_duration + ' min' }}</p>

                    <div class="button-column">
                        <router-link
                            :to="{ path: `/admin/home/subjects/${quiz.subject_id}/chapters/${quiz.chapter_id}/quizzes/${quiz.quiz_id}` }"
                            class="btn btn-info me-2" title="View Quiz">View
                            Quiz</router-link>

                        <button data-bs-toggle="modal" data-bs-target="#editQuizModal" class="btn btn-warning me-2 edit"
                            @click="assignQuiz(quiz)" title="Edit QUiz">
                            <i class="fa fa-edit"></i>
                        </button>

                        <!-- Edit Quiz Modal -->
                        <div class="modal fade" id="editQuizModal" tabindex="-1" aria-labelledby="editQuizModalLabel"
                            aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title ms-1" id="editQuizModalLabel">Edit Quiz
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-floating mb-3 mx-2">
                                            <input v-model="editQuizData.quiz_name" type="text" class="form-control"
                                                id="editQuizName" placeholder="Enter quiz name" required>
                                            <label for="editQuizName" class="form-label">Quiz Name</label>
                                        </div>
                                        <div class="form-floating mb-3 mx-2">
                                            <input v-model="editQuizData.remarks" type="text" class="form-control"
                                                id="quizRemarks" placeholder="Enter remarks" />
                                            <label for="quizRemarks" class="form-label">Remarks</label>
                                        </div>
                                        <div class="form-floating mb-3 mx-2">
                                            <input v-model="editQuizData.quiz_schedule" type="datetime-local"
                                                class="form-control" id="quizSchedule" placeholder="Enter quiz schedule"
                                                :min="minDate" />
                                            <label for="quizSchedule" class="form-label">Quiz Schedule</label>
                                        </div>
                                        <div class="form-floating mb-3 mx-2">
                                            <input v-model="editQuizData.time_duration" type="time" class="form-control"
                                                id="quizDuration" placeholder="Enter duration in HH:MM" />
                                            <label for="quizDuration" class="form-label">Time Duration
                                                (HH:MM)</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                            ref="cancelEditQuiz" id="cancelEditQuiz">Cancel</button>
                                        <button type="button" class="btn btn-primary" @click="updateQuiz">Save
                                            Changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <button :class="['btn', quiz.quiz_status === 'Active' ? 'btn-success' : 'btn-danger']"
                            @click="toggleQuizStatus(quiz)"
                            :title="quiz.quiz_status === 'Active' ? 'Click to Deactivate' : 'Click to Activate'">
                            <i :class="quiz.quiz_status === 'Active' ? 'fa fa-toggle-on' : 'fa fa-toggle-off'"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</template>

<script>
export default {
    data() {
        return {
            searchQuery: "",
            quizzes: [],
            subjects: [],
            chapters: [],
            filteredQuizzes: [],
            newQuiz: { subject_id: null, chapter_id: null, quiz_name: "", quiz_schedule: null, time_duration: null, remarks: "" },
            editQuizData: { quiz_id: null, quiz_name: "", quiz_schedule: null, time_duration: null, remarks: "" },
            minDate: new Date(new Date().getTime()).toISOString().slice(0, 16),
        };
    },
    mounted() {
        this.fetchHome();
    },
    methods: {
        async fetchHome() {
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/home", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.quizzes = data.quizzes || [];
                    this.subjects = data.subjects
                    this.filteredQuizzes = this.quizzes;
                } else {
                    const errorData = await response.json();
                    console.error("Failed to fetch Quizzes", errorData.msg);
                    alert("Error: " + errorData.msg);
                }
            } catch (error) {
                console.error("Error in fetching:", error);
            }
        },

        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },


        searchQuizzes() {
            const query = this.searchQuery.toLowerCase();

            this.filteredQuizzes = this.quizzes.filter(quiz => {
                const scheduleStatus = quiz.quiz_schedule ? `attempt after ${this.formatDateTime(quiz.quiz_schedule)}` : "attempt anytime";
                return ((quiz.quiz_name?.toLowerCase() || "").includes(query) ||
                    (quiz.remarks?.toLowerCase() || "").includes(query) ||
                    (quiz.time_duration?.toLowerCase() || "").includes(query) ||
                    scheduleStatus.includes(query)
                );
            });
        },


        async fetchChaptersForSubject() {
            const subject_id = this.newQuiz.subject_id;
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/home/subject/${subject_id}/chapters`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.chapters = data.chapters || [];
                    console.warn(data)
                    console.warn(this.chapters)
                } else {
                    alert("Failed to fetch chapters for the selected subject");
                }
            } catch (error) {
                console.error("Error fetching chapters:", error);
            }
        },


        async addQuiz() {
            if (!this.newQuiz.chapter_id) {
                alert("Please select a chapter.");
                return;
            }
            if (!this.newQuiz.quiz_name.trim()) {
                alert("Please enter a quiz name.");
                return;
            }


            try {
                const response = await fetch("http://127.0.0.1:5000/admin/add/quiz", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        chapter_id: this.newQuiz.chapter_id,
                        quiz_name: this.newQuiz.quiz_name,
                        quiz_schedule: this.newQuiz.quiz_schedule,
                        time_duration: this.newQuiz.time_duration,
                        remarks: this.newQuiz.remarks,
                    }),
                });
                if (response.ok) {
                    alert("Quiz added successfully");
                    this.fetchHome();
                    this.newQuiz = { subject_id: null, quiz_name: "", time_duration: null };
                    this.$refs.cancelButtonQuiz.click();
                } else {
                    const errorData = await response.json();
                    alert("Failed to add quiz: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error adding quiz:", error);
            }
        },

        convertToHHMM(totalMinutes) {
            const hours = Math.floor(totalMinutes / 60);
            const minutes = totalMinutes % 60;

            const formattedHours = String(hours).padStart(2, '0');
            const formattedMinutes = String(minutes).padStart(2, '0');

            return `${formattedHours}:${formattedMinutes}`;
        },

        assignQuiz(quiz) {
            let duration;

            if (quiz.time_duration === "No Time Limit") {
                duration = "00:00";
            } else {
                duration = this.convertToHHMM(quiz.time_duration);
            }

            this.editQuizData = {
                quiz_id: quiz.quiz_id,
                quiz_name: quiz.quiz_name,
                quiz_schedule: quiz.quiz_schedule,
                time_duration: duration,
                remarks: quiz.remarks,
            };
        },

        async updateQuiz() {
            const { quiz_id, quiz_name, quiz_schedule, time_duration, remarks } = this.editQuizData;

            if (!quiz_name.trim()) {
                alert("Please enter a quiz name.");
                return;
            }


            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/quizzes/${quiz_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        quiz_name: quiz_name,
                        quiz_schedule: quiz_schedule,
                        time_duration: time_duration,
                        remarks: remarks,
                    }),
                });

                if (response.ok) {
                    alert("Quiz updated successfully");
                    this.fetchHome();
                    document.getElementById("cancelEditQuiz").click();

                } else {
                    const errorData = await response.json();
                    alert("Failed to update quiz: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating quiz:", error);
            }
        },


        async toggleQuizStatus(quiz) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/toggle/quiz/${quiz.quiz_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    quiz.quiz_status = data.status;
                    this.fetchHome();
                } else {
                    const errorData = await response.json();
                    alert("Failed to toggle status: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error toggling subject status:", error);
            }
        },


    },
};
</script>

<style scoped>
.admin-quizzes {
    padding: 20px;
}

.search-box {
    width: 85%;
}

.search-box input {
    margin-top: 3px;
    width: 95%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.add-quiz-btn {
    width: 15%;
    padding: 10px;
    border-radius: 5px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.quiz {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

.edit {
    color: white;
}
</style>
