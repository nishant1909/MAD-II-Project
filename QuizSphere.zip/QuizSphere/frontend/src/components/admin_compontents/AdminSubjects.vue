<template>
    <div class="admin-home-subject">
        <h2>All Subjects</h2>
        <!-- Search Box container -->
        <div class="search-add-container d-flex mb-3">
            <!-- Search Box -->
            <div class="search-box">
                <input type="text" v-model="searchQuery" @input="searchSubjects" placeholder="Search subjects..."
                    class="form-control" />
            </div>

            <!-- Add New Subject Button -->
            <button class="btn btn-primary add-subject-btn" data-bs-toggle="modal" data-bs-target="#addSubjectModal">
                &#43; Add New Subject
            </button>
        </div>

        <!-- Add subject modal -->
        <div class="modal fade" id="addSubjectModal" tabindex="-1" aria-labelledby="addSubjectModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title ms-1" id="addSubjectModalLabel">Add New Subject</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-floating mb-3 mx-2">
                            <input v-model="newSubject.subject_name" type="text" class="form-control" required
                                id="subjectName" placeholder="Enter subject name" />
                            <label for="subjectName" class="form-label">Subject Name</label>
                        </div>
                        <div class="form-floating mb-3 mx-2">
                            <textarea v-model="newSubject.subject_description" class="form-control"
                                id="subjectDescription" rows="3" placeholder="Enter subject description"
                                required></textarea>
                            <label for="subjectDescription" class="form-label">Subject Description</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                            ref="cancelButtonSubject">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="addSubject">Save</button>
                    </div>
                </div>
            </div>
        </div>


        <!-- Subjects Grid -->
        <div v-if="filteredSubjects.length === 0" class="text-center">
            No Subject with this Query!
        </div>
        <div class="grid">
            <div v-for="subject in filteredSubjects" :key="subject.subject_id" class="card">
                <div class="img">
                    <img src="../../assets/logo.png" class="logo">
                    <img src="../../assets/subject.jpg" class="subject">
                </div>
                <div class="card-body text-start ms-2">
                    <h4 class="card-title">{{ subject.subject_name }}</h4>
                    <p class="card-text">{{ subject.subject_description }}</p>

                    <div class="button-column">
                        <router-link :to="{ path: `${$route.path}/${subject.subject_id}/chapters` }"
                            class="btn btn-info me-2" title="View Chapters">View
                            Chapters</router-link>

                        <button data-bs-toggle="modal" data-bs-target="#editSubjectModal"
                            class="btn btn-warning me-2 edit" @click="assignSubject(subject)" title="Edit Subject">
                            <i class="fa fa-edit"></i>
                        </button>

                        <!-- Edit Subject Modal -->
                        <div class="modal fade" id="editSubjectModal" tabindex="-1"
                            aria-labelledby="editSubjectModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title ms-1" id="editSubjectModalLabel">Edit Subject
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-floating mb-3 mx-2">
                                            <input v-model="editSubjectData.subject_name" type="text"
                                                class="form-control" id="editSubjectName"
                                                placeholder="Enter subject name" required />
                                            <label for="editSubjectName" class="form-label">Subject Name</label>
                                        </div>
                                        <div class="form-floating mb-3 ms-2">
                                            <textarea v-model="editSubjectData.subject_description" class="form-control"
                                                id="editSubjectDescription" rows="3"
                                                placeholder="Enter subject description" required></textarea>
                                            <label for="editSubjectDescription" class="form-label">Subject
                                                Description</label>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                            id="cancelEditSubject" ref="cancelEditSubject">
                                            Cancel
                                        </button>

                                        <button type="button" class="btn btn-primary" @click="updateSubject">Save
                                            Changes</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Toggle subject data -->
                        <button :class="['btn', subject.subject_status === 'Active' ? 'btn-success' : 'btn-danger']"
                            @click="toggleSubjectStatus(subject)"
                            :title="subject.subject_status === 'Active' ? 'Click to Deactivate' : 'Click to Activate'">
                            <i
                                :class="subject.subject_status === 'Active' ? 'fa fa-toggle-on' : 'fa fa-toggle-off'"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            searchQuery: "",
            subjects: [],
            filteredSubjects: [],
            newSubject: { subject_name: "", subject_description: "" },
            editSubjectData: { subject_id: null, subject_name: "", subject_description: "" },
        };
    },
    mounted() {
        this.fetchHome()
    },
    methods: {
        async fetchHome() {
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/home", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.subjects = data.subjects || [];
                    this.filteredSubjects = this.subjects;
                } else {
                    const errorData = await response.json();
                    console.error("Failed to fetch Subjects", errorData.msg);
                    alert("Error: " + errorData.msg);
                }
            } catch (error) {
                console.error("Error in fetching:", error);
            }
        },

        searchSubjects() {
            const query = this.searchQuery.toLowerCase();
            this.filteredSubjects = this.subjects.filter(subject =>
                subject.subject_name.toLowerCase().includes(query) || subject.subject_description.toLowerCase().includes(query)
            );
        },

        async addSubject() {
            if (!this.newSubject.subject_name.trim() || !this.newSubject.subject_description.trim()) {
                alert("Please fill out both the subject name and description.");
                return;
            }
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/add/subject", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        name: this.newSubject.subject_name,
                        description: this.newSubject.subject_description,
                    }),
                });
                if (response.ok) {
                    alert("Subject added successfully");
                    this.fetchHome();
                    this.newSubject = { subject_name: "", subject_description: "" };
                    this.$refs.cancelButtonSubject.click();
                } else {
                    alert("Failed to add subject");
                }
            } catch (error) {
                console.error("Error adding subject:", error);
            }
        },

        assignSubject(subject) {
            this.editSubjectData = {
                subject_id: subject.subject_id,
                subject_name: subject.subject_name,
                subject_description: subject.subject_description,
            };
        },

        async updateSubject() {
            const { subject_id, subject_name, subject_description } = this.editSubjectData;

            if (!subject_name.trim() || !subject_description.trim()) {
                alert("Please fill out both the subject name and description.");
                return;
            }

            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/subjects/${subject_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        name: subject_name,
                        description: subject_description,
                    }),
                });

                if (response.ok) {
                    alert("Subject updated successfully");
                    this.fetchHome();
                    document.getElementById("cancelEditSubject").click();

                } else {
                    const errorData = await response.json();
                    alert("Failed to update subject: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating subject:", error);
            }
        },

        async toggleSubjectStatus(subject) {
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/toggle/subject/${subject.subject_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    subject.subject_status = data.status;
                    this.fetchHome();
                } else {
                    const errorData = await response.json();
                    alert("Failed to toggle status: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error toggling subject status:", error);
            }
        },


    },
};
</script>

<style scoped>
.admin-home-subject {
    padding: 20px;
}

.search-box {
    width: 85%;
}

.search-box input {
    margin-top: 3px;
    width: 95%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.add-subject-btn {
    width: 15%;
    padding: 10px;
    border-radius: 5px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

.subject {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.edit {
    color: white;
}
</style>
