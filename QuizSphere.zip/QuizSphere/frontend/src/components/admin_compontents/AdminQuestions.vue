<template>
    <div class="admin-questions-page">
        <h2>Quiz Details</h2>

        <!-- Quiz Information Section -->
        <div class="quiz-info-box mb-4">
            <div class="text-start ms-3 mt-2 fs-3">
                <div class="d-flex mb-3">
                    <div class="quiz-detail"><strong>Subject:</strong> {{ subject_name }}</div>
                    <div class="quiz-detail"><strong>Chapter:</strong> {{ chapter_name }}</div>
                    <div class="quiz-detail"><strong>Quiz Name:</strong> {{ quiz.quiz_name }}</div>
                </div>
                <div class="d-flex mb-3">
                    <div style="width: 66%;"><strong>Schedule:</strong> {{ formatDateTime(quiz.quiz_schedule) ||
                        'Attempt Anytime'
                        }}</div>
                    <div class="quiz-detail"><strong>Time Duration:</strong> {{ quiz.time_duration === 'No Time Limit'
                        ? 'No Time Limit' :
                        quiz.time_duration + ' min' }}</div>
                </div>
                <div class="d-flex">
                    <div style="width: 93%;"><strong>Remarks:</strong> {{ quiz.remarks || 'No Remarks' }}</div>

                    <div style="width: 5%;">
                        <button data-bs-toggle="modal" data-bs-target="#editQuizModal" class="btn btn-warning me-2 edit"
                            @click="assignQuiz(quiz)" title="Edit QUiz">
                            <i class="fa fa-edit"></i>
                        </button>
                    </div>

                </div>

            </div>
        </div>

        <!-- Edit Quiz Modal -->
        <div class="modal fade" id="editQuizModal" tabindex="-1" aria-labelledby="editQuizModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title ms-1" id="editQuizModalLabel">Edit Quiz
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-floating mb-3 mx-2">
                            <input v-model="editQuizData.quiz_name" type="text" class="form-control" id="editQuizName"
                                placeholder="Enter quiz name" required>
                            <label for="editQuizName" class="form-label">Quiz Name</label>
                        </div>
                        <div class="form-floating mb-3 mx-2">
                            <input v-model="editQuizData.remarks" type="text" class="form-control" id="quizRemarks"
                                placeholder="Enter remarks" />
                            <label for="quizRemarks" class="form-label">Remarks</label>
                        </div>
                        <div class="form-floating mb-3 mx-2">
                            <input v-model="editQuizData.quiz_schedule" type="datetime-local" class="form-control"
                                id="quizSchedule" placeholder="Enter quiz schedule" />
                            <label for="quizSchedule" class="form-label">Quiz Schedule</label>
                        </div>
                        <div class="form-floating mb-3 mx-2">
                            <input v-model="editQuizData.time_duration" type="time" class="form-control"
                                id="quizDuration" placeholder="Enter duration in HH:MM" />
                            <label for="quizDuration" class="form-label">Time Duration
                                (HH:MM)</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" ref="cancelEditQuiz"
                            id="cancelEditQuiz">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="updateQuiz">Save
                            Changes</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Questions Section -->
        <div v-if="questions.length === 0">
            No questions added yet.
        </div>


        <div v-else class="questions-container">
            <ol class="ps-0">
                <div v-for="question in questions" :key="question.question_id" class="card question-card text-start">
                    <div class="card-body ms-2">
                        <div class="d-flex">
                            <div style="width: 88%;">
                                <h4 class="card-title d-flex"><strong>Q</strong>
                                    <li style="margin-left: 3.4%;">{{ question.question_statement }}</li>
                                </h4>

                                <div>

                                    <h5 class="ms-4 mt-2 mb-4 text-success"><strong>Answer: </strong>
                                        {{ ['a', 'b', 'c', 'd'][question.correct_option - 1] }}. {{
                                            question['option' +
                                            question.correct_option]
                                        }}
                                    </h5>


                                    <ol type="a" class="ms-4">
                                        <h5>
                                            <li class="mb-2">{{ question.option1 }} </li>
                                            <li class="mb-2">{{ question.option2 }} </li>
                                            <li class="mb-2">{{ question.option3 }} </li>
                                            <li class="mb-2">{{ question.option4 }} </li>
                                        </h5>
                                    </ol>
                                </div>

                            </div>

                            <div style="width: 12%;" class="ms-3">
                                <h4 class="fw-semibold">{{ question.marks }} marks </h4>

                                <div class="action-for-question mt-3">
                                    <button data-bs-toggle="modal" data-bs-target="#editQuestionModal"
                                        class="btn btn-warning me-2 edit" @click="assignQuestion(question)"
                                        title="Edit Question">
                                        <i class="fa fa-edit"></i>
                                    </button>

                                    <!-- Edit Question Modal -->
                                    <div class="modal fade" id="editQuestionModal" tabindex="-1"
                                        aria-labelledby="editQuestionModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title ms-1" id="editQuestionModalLabel">Edit
                                                        Question
                                                    </h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body mx-2">
                                                    <div class="form-floating mb-3">
                                                        <textarea v-model="editQuestionData.question_statement"
                                                            type="text" class="form-control" id="questionStatement"
                                                            placeholder="Enter question statement" required></textarea>
                                                        <label for="questionStatement" class="form-label">Question
                                                            Statement</label>
                                                    </div>
                                                    <div class="form-floating mb-3">
                                                        <input v-model="editQuestionData.marks" type="number"
                                                            class="form-control" id="marks"
                                                            placeholder="Enter correct option" required />
                                                        <label for="marks" class="form-label">Marks</label>
                                                    </div>
                                                    <div class="form-floating mb-3">
                                                        <input v-model="editQuestionData.option1" type="text"
                                                            class="form-control" id="editOption1"
                                                            placeholder="Enter option 1" required />
                                                        <label for="editOption1" class="form-label">Option 1</label>
                                                    </div>

                                                    <div class="form-floating mb-3">
                                                        <input v-model="editQuestionData.option2" type="text"
                                                            class="form-control" id="editOption2"
                                                            placeholder="Enter option 2" required />
                                                        <label for="editOption2" class="form-label">Option 2</label>
                                                    </div>

                                                    <div class="form-floating mb-3">
                                                        <input v-model="editQuestionData.option3" type="text"
                                                            class="form-control" id="editOption3"
                                                            placeholder="Enter option 3" required />
                                                        <label for="editOption3" class="form-label">Option 3</label>
                                                    </div>

                                                    <div class="form-floating mb-3">
                                                        <input v-model="editQuestionData.option4" type="text"
                                                            class="form-control" id="editOption4"
                                                            placeholder="Enter option 4" required />
                                                        <label for="editOption4" class="form-label">Option 4</label>
                                                    </div>

                                                    <div class="form-floating mb-3">
                                                        <input v-model="editQuestionData.correct_option" type="number"
                                                            class="form-control" id="correctOption"
                                                            placeholder="Enter correct option" required />
                                                        <label for="correctOption" class="form-label">Correct
                                                            Option</label>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal" id="cancelEditQuestion">Cancel</button>
                                                    <button type="button" class="btn btn-primary"
                                                        @click="updateQuestion">Save
                                                        Changes</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <button class="btn btn-danger delete" @click="deleteQuestion(question.question_id)"
                                        title="Delete Question">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
            </ol>
        </div>

        <!-- Add New Question Button -->
        <button class="btn btn-primary mt-4" data-bs-toggle="modal" data-bs-target="#addQuestionModal"
            title="Add New Question">&#43; Add New
            Question</button>

        <!-- Add Question Modal -->
        <div class="modal fade" id="addQuestionModal" tabindex="-1" aria-labelledby="addQuestionModalLabel"
            aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title ms-1" id="addQuestionModalLabel">Add New Question
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body mx-2">
                        <div class="form-floating mb-3">
                            <textarea v-model="newQuestion.question_statement" type="text" class="form-control"
                                id="questionStatement" placeholder="Enter question statement" required></textarea>
                            <label for="questionStatement" class="form-label">Question
                                Statement</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input v-model="newQuestion.marks" type="number" class="form-control" id="marks"
                                placeholder="Enter correct option" required />
                            <label for="marks" class="form-label">Marks</label>
                        </div>
                        <div class="form-floating mb-3">
                            <input v-model="newQuestion.option1" type="text" class="form-control" id="editOption1"
                                placeholder="Enter option 1" required />
                            <label for="editOption1" class="form-label">Option 1</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input v-model="newQuestion.option2" type="text" class="form-control" id="editOption2"
                                placeholder="Enter option 2" required />
                            <label for="editOption2" class="form-label">Option 2</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input v-model="newQuestion.option3" type="text" class="form-control" id="editOption3"
                                placeholder="Enter option 3" required />
                            <label for="editOption3" class="form-label">Option 3</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input v-model="newQuestion.option4" type="text" class="form-control" id="editOption4"
                                placeholder="Enter option 4" required />
                            <label for="editOption4" class="form-label">Option 4</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input v-model="newQuestion.correct_option" type="number" class="form-control"
                                id="correctOption" placeholder="Enter correct option" required />
                            <label for="correctOption" class="form-label">Correct
                                Option</label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                            id="cancelAddQuestion">Cancel</button>
                        <button type="button" class="btn btn-primary" @click="addQuestion">Save
                            Changes</button>
                    </div>
                </div>
            </div>
        </div>


    </div>
</template>

<script>
export default {
    props: ["subject_id", "chapter_id", "quiz_id"],
    data() {
        return {
            subject_name: "",
            chapter_name: "",
            quiz: [],
            editQuizData: { quiz_id: null, quiz_name: "", quiz_schedule: null, time_duration: null, remarks: "" },
            questions: [],
            editQuestionData: { question_id: null, question_statement: "", marks: null, option1: "", option2: "", option3: "", option4: "", correct_option: null },
            newQuestion: { question_statement: "", marks: null, option1: "", option2: "", option3: "", option4: "", correct_option: null },
        };
    },
    mounted() {
        this.fetchQuestions();
    },
    methods: {
        async fetchQuestions() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/subject/${this.subject_id}/chapter/${this.chapter_id}/quiz/${this.quiz_id}/questions`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${localStorage.getItem("token")}`,
                        },
                    }
                );
                if (response.ok) {
                    const data = await response.json();
                    this.subject_name = data.subject_name;
                    this.chapter_name = data.chapter_name;
                    this.quiz = data.quiz[0];
                    this.questions = data.questions || [];
                } else {
                    alert("Failed to fetch questions");
                }
            } catch (error) {
                console.error("Error fetching questions:", error);
            }
        },

        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },

        convertToHHMM(totalMinutes) {
            const hours = Math.floor(totalMinutes / 60);
            const minutes = totalMinutes % 60;

            const formattedHours = String(hours).padStart(2, '0');
            const formattedMinutes = String(minutes).padStart(2, '0');

            return `${formattedHours}:${formattedMinutes}`;
        },

        assignQuiz(quiz) {
            let duration;

            if (quiz.time_duration === "No Time Limit") {
                duration = "00:00";
            } else {
                duration = this.convertToHHMM(quiz.time_duration);
            }

            this.editQuizData = {
                quiz_id: quiz.quiz_id,
                quiz_name: quiz.quiz_name,
                quiz_schedule: quiz.quiz_schedule,
                time_duration: duration,
                remarks: quiz.remarks,
            };
        },

        async updateQuiz() {
            const { quiz_id, quiz_name, quiz_schedule, time_duration, remarks } = this.editQuizData;

            if (!quiz_name.trim()) {
                alert("Please enter a quiz name.");
                return;
            }


            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/quizzes/${quiz_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        quiz_name: quiz_name,
                        quiz_schedule: quiz_schedule,
                        time_duration: time_duration,
                        remarks: remarks,
                    }),
                });

                if (response.ok) {
                    alert("Quiz updated successfully");
                    this.fetchQuestions();
                    document.getElementById("cancelEditQuiz").click();

                } else {
                    const errorData = await response.json();
                    alert("Failed to update quiz: " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating quiz:", error);
            }
        },

        assignQuestion(question) {
            this.editQuestionData = {
                question_id: question.question_id,
                question_statement: question.question_statement,
                marks: question.marks,
                option1: question.option1,
                option2: question.option2,
                option3: question.option3,
                option4: question.option4,
                correct_option: question.correct_option,
            };
        },


        async updateQuestion() {
            const { question_id, question_statement, marks, option1, option2, option3, option4, correct_option } = this.editQuestionData;
            if (!question_statement.trim() || !String(marks).trim() || !option1.trim() || !option2.trim() || !option3.trim() || !option4.trim() || !String(correct_option).trim()) {
                alert("Please fill all data of question to edit.");
                return;
            }
            if (correct_option > 4 || correct_option < 1) {
                alert("Please fill correct option in range 1-4.")
                return;
            }

            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/questions/${question_id}`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`
                    },
                    body: JSON.stringify({
                        question_statement: question_statement,
                        marks: marks,
                        option1: option1,
                        option2: option2,
                        option3: option3,
                        option4: option4,
                        correct_option: correct_option,
                    }),
                });

                if (response.ok) {
                    alert("Question updated successfully");
                    this.fetchQuestions();
                    document.getElementById("cancelEditQuestion").click();
                } else {
                    const errorData = await response.json();
                    alert("Failed to update question " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating question:", error);
            }
        },


        async addQuestion() {
            if (!this.newQuestion.question_statement.trim() || !String(this.newQuestion.marks).trim() || !this.newQuestion.option1.trim() || !this.newQuestion.option2.trim() || !this.newQuestion.option3.trim() || !this.newQuestion.option4.trim() || !String(this.newQuestion.correct_option).trim()) {
                alert("Please fill all data of question to edit.");
                return;
            }
            if (this.newQuestion.correct_option > 4 || this.newQuestion.correct_option < 1) {
                alert("Please fill correct option in range 1-4.")
                return;
            }
            try {
                const response = await fetch(`http://127.0.0.1:5000/admin/quiz/${this.quiz_id}/add/question`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`
                    },
                    body: JSON.stringify({
                        question_statement: this.newQuestion.question_statement,
                        marks: this.newQuestion.marks,
                        option1: this.newQuestion.option1,
                        option2: this.newQuestion.option2,
                        option3: this.newQuestion.option3,
                        option4: this.newQuestion.option4,
                        correct_option: this.newQuestion.correct_option,
                    })
                });
                if (response.ok) {
                    alert("Question added successfully");
                    this.fetchQuestions();
                    this.newQuestion = { question_statement: "", marks: null, option1: "", option2: "", option3: "", option4: "", correct_option: null }
                    document.getElementById("cancelAddQuestion").click();
                } else {
                    alert("Failed to add question");
                }
            } catch (error) {
                console.error("Error adding question:", error);
            }
        },


        async deleteQuestion(question_id) {
            if (confirm("Are you sure you want to delete this question?")) {
                try {
                    const response = await fetch(`http://127.0.0.1:5000/admin/questions/${question_id}`, {
                        method: "DELETE",
                        headers: {
                            Authorization: `Bearer ${localStorage.getItem("token")}`
                        }
                    });
                    if (response.ok) {
                        alert("Question deleted successfully");
                        this.fetchQuestions();
                    } else {
                        alert("Failed to delete question");
                    }
                } catch (error) {
                    console.error("Error deleting question:", error);
                }
            }
        }
    }
};
</script>

<style scoped>
.admin-questions-page {
    padding: 20px;
}

.quiz-info-box {
    border: 1px solid #ddd;
    padding: 15px;
    border-radius: 8px;
    background-color: #e9e9e9;
    box-shadow: 3px 3px 5px rgba(0, 0, 0, 0.1);
}


.quiz-detail {
    width: 33%;
}

.question-card {
    margin-bottom: 15px;
    background-color: #f9f9f9;
    box-shadow: 3px 3px 5px rgba(0, 0, 0, 0.1);

}

.edit {
    color: white;
}

.delete:hover {
    color: red;
    background-color: white;
}
</style>
