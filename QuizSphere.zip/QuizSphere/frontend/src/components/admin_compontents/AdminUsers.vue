<template>
    <div class="admin-users-page">
        <div class="d-flex justify-content-between align-items-center">
            <div class="me-5"></div>
            <h2 class="ms-5">Manage Users</h2>
            <div class="d-flex align-items-end">
                <button v-if="!loading" class="btn btn-primary" @click="downloadCSV">Generate Users
                    CSV</button>
                <p v-if="loading" class="ms-3 text-primary">Generating...</p>
            </div>
        </div>


        <div class="search-box mb-3">
            <input type="text" v-model="searchQuery" @input="searchUsers" placeholder="Search users..."
                class="form-control" />
        </div>

        <div v-if="filteredUsers.length === 0" class="no-data">
            No users with this query.
        </div>

        <div v-else class="users-table">
            <table class="table table-bordered text-start table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Qualification</th>
                        <th class="text-center">Date of Birth</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(user, index) in filteredUsers" :key="user.user_id">
                        <td class="fw-semibold">{{ index + 1 }}</td>
                        <td>{{ user.full_name }}</td>
                        <td>{{ user.email }}</td>
                        <td>{{ user.qualification }}</td>
                        <td class="text-center">{{ formatDate(user.dob) }}</td>
                        <td class="text-center">
                            <span
                                :class="['mt-2 badge rounded-pill', user.status !== 'Active' ? 'bg-danger' : 'bg-success']">
                                {{ user.status !== 'Active' ? 'Blocked' : 'Active' }}
                            </span>
                        </td>
                        <td class="text-center">
                            <button
                                :class="['btn', 'text-white', 'fw-semibold', user.status !== 'Active' ? 'bg-success' : 'bg-danger']"
                                @click="buttonBlockUnblock(user)" style="min-width: 100px;">
                                {{ user.status !== 'Active' ? 'Unblock' : 'Block' }}
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            users: [],
            filteredUsers: [],
            searchQuery: "",
            loading: false,
            task_id: null,
            interval: null,
        };
    },
    mounted() {
        this.fetchUsers();
    },

    methods: {
        async fetchUsers() {
            try {
                const response = await fetch("http://127.0.0.1:5000/admin/users", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    this.users = data.users;
                    this.filteredUsers = data.users;
                } else {
                    alert("Failed to fetch users");
                }
            } catch (error) {
                console.error("Error fetching users:", error);
            }
        },

        async downloadCSV() {
            this.loading = true;
            const response = await fetch("http://127.0.0.1:5000/admin/export/csv", {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            if (response.ok) {
                const data = await response.json();
                this.task_id = data.task_id;
                this.interval = setInterval(() => {
                    this.checkTaskStatus();
                }, 100);
            }
        },

        async checkTaskStatus() {
            const response = await fetch(`http://127.0.0.1:5000/admin/get/csv/${this.task_id}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            if (response.ok) {
                this.loading = false;
                window.open(`http://127.0.0.1:5000/admin/get/csv/${this.task_id}`)
                clearInterval(this.interval);
            } else {
                alert("Failed to download CSV");
            }
        },

        searchUsers() {
            const query = this.searchQuery.toLowerCase();

            this.filteredUsers = this.users.filter(user => {
                const userDob = user.dob.toLowerCase();
                const formattedQuery = query.replace(/\//g, "");

                return (
                    user.full_name.toLowerCase().includes(query) ||
                    user.email.toLowerCase().includes(query) ||
                    user.qualification.toLowerCase().includes(query) ||
                    userDob.includes(formattedQuery) || // Match dob without slashes
                    (user.status == 'Inactive' ? 'blocked' : 'active').includes(query)
                );
            });
        },

        formatDate(dob) {
            const date = new Date(dob);
            return date.toLocaleDateString("en-GB");
        },


        async buttonBlockUnblock(user) {
            const action = user.status !== 'Active' ? "unblock" : "block";
            if (
                confirm(
                    `Are you sure you want to ${action} the user "${user.full_name}" (${user.email})?`
                )
            ) {
                try {
                    const response = await fetch(
                        `http://127.0.0.1:5000/admin/users/${user.user_id}/${action}`,
                        {
                            method: "PUT",
                            headers: {
                                "Content-Type": "application/json",
                                Authorization: `Bearer ${localStorage.getItem("token")}`,
                            },
                        }
                    );

                    if (response.ok) {
                        // alert(`User ${action}ed successfully`);
                        this.fetchUsers();
                    } else {
                        alert(`Failed to ${action} the user`);
                    }
                } catch (error) {
                    console.error(`Error trying to ${action} user:`, error);
                }
            }
        },
    },
};
</script>

<style scoped>
.admin-users-page {
    padding: 20px;
}

.search-box {
    width: 100%;
}

.search-box input {
    margin-top: 3px;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.table {
    width: 100%;
    margin-top: 20px;
}

/* .badge {padding: 5px 10px;
    border-radius: 5px;
} */

.no-data {
    text-align: center;
    margin-top: 20px;
    font-size: 1.2rem;
    color: gray;
}
</style>
