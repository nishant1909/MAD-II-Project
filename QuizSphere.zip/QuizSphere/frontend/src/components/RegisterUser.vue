<template>
    <div class="register-page mt-2">
        <div class="form-container">
            <h2 class="mb-3">Register</h2>
            <form @submit.prevent="registerUser">
                <div class="form-floating mb-3 mx-2">
                    <input type="text" id="full_name" v-model="full_name" class="form-control" required
                        placeholder="Enter your full_name" />
                    <label for="full_name" class="form-label">Full Name</label>
                </div>
                <div class="form-floating mb-3 mx-2">
                    <input type="email" id="email" v-model="email" class="form-control" required
                        placeholder="Enter your email" />
                    <label for="email" class="form-label">Email</label>
                </div>
                <div class="form-floating mb-3 mx-2">
                    <input type="password" id="password" v-model="password" class="form-control" required
                        placeholder="Enter your password" />
                    <label for="password" class="form-label">Password</label>
                </div>
                <div class="form-floating mb-3 mx-2">
                    <input type="text" id="qualification" v-model="qualification" class="form-control"
                        placeholder="Enter your qualification" />
                    <label for="qualification" class="form-label">Qualification</label>
                </div>
                <div class="form-floating mb-3 mx-2">
                    <input type="date" id="dob" v-model="dob" :max="maxDate" class="form-control" required />
                    <label for="dob" class="form-label">Date of Birth</label>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-1 p-2">Register</button>
            </form>
            <p class="login-link mt-3">Already have an account? <router-link to="/login">Login here</router-link>.</p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            full_name: "",
            email: "",
            password: "",
            qualification: "",
            dob: "",
            maxDate: new Date().toISOString().split('T')[0],
        };
    },
    methods: {
        async registerUser() {
            if (!this.full_name.trim() || !this.email.trim() || !this.password.trim() || !this.qualification.trim() || !this.dob.trim()) {
                alert("Please fill all input field.");
                return;
            }
            try {
                const response = await fetch("http://127.0.0.1:5000/user/register", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        full_name: this.full_name,
                        email: this.email,
                        password: this.password,
                        qualification: this.qualification,
                        dob: this.dob,
                    }),
                });

                const data = await response.json();

                if (response.ok) {
                    alert("Registration successful! Please log in.");
                    this.$router.push("/login");
                } else {
                    alert(`Registration failed: ${data.error || data.message}`);
                }
            } catch (error) {
                console.error("Error during registration:", error);
                alert("An error occurred. Please try again later.");
            }
        },
    },
};
</script>

<style scoped>
.register-page {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: #f8f9fa;
    font-family: Arial, sans-serif;
}

.form-container {
    background: white;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 450px;
}

input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.login-link {
    font-size: 14px;
}

.login-link a {
    color: #007bff;
    text-decoration: none;
}

.login-link a:hover {
    text-decoration: underline;
}
</style>
