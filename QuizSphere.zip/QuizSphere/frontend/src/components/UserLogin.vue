<template>
    <div class="login-page mt-2">
        <div class="form-container">
            <h2 class="mb-4">Login</h2>
            <form @submit.prevent="loginUser">
                <div class="form-floating mb-3 mx-2">
                    <input type="text" id="email" v-model="email" class="form-control" required
                        placeholder="Enter your email" />
                    <label for="email" class="form-label">Email ID</label>
                </div>
                <div class="form-floating mb-3 mx-2">
                    <input type="password" id="password" v-model="password" class="form-control" required
                        placeholder="Enter your password" />
                    <label for="password" class="form-label">Password</label>
                </div>
                <button type="submit" class="btn btn-primary w-100 mt-1 p-2">Login</button>
            </form>
            <p class="register-link">Don't have an account? <router-link to="/user/register">Register
                    here</router-link>.</p>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            email: "",
            password: "",
        };
    },
    methods: {
        async loginUser() {
            try {
                const response = await fetch("http://127.0.0.1:5000/login", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({
                        email: this.email,
                        password: this.password,
                    }),
                });

                const data = await response.json();

                if (response.ok) {
                    // Store token in localStorage
                    console.log(data);
                    localStorage.setItem("token", data.token);
                    localStorage.setItem("user_id", data.user.user_id);
                    localStorage.setItem("email", data.user.email);
                    localStorage.setItem("role", data.user.role);
                    localStorage.setItem("status", data.user.status);

                    // Redirect based on role
                    if (data.user.role === "Admin") {
                        this.$router.push("/admin/home");
                    } else if (data.user.role === "User") {
                        this.$router.push(`/user/${data.user.user_id}/home`);
                    }
                } else {
                    alert(`Login failed: ${data.error || data.message}`);
                }
            } catch (error) {
                console.error("Error during login:", error);
                alert("An error occurred. Please try again later.");
            }
        },
    },
};
</script>

<style scoped>
.login-page {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: #f8f9fa;
    font-family: Arial, sans-serif;
}

.form-container {
    background: white;
    padding: 20px 30px;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    width: 100%;
    max-width: 450px;
}

.form-group {
    margin-bottom: 15px;
}

input {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 14px;
}

.btn:hover {
    background: #0056b3;
}

.register-link {
    margin-top: 15px;
    text-align: center;
    font-size: 14px;
}

.register-link a {
    color: #007bff;
    text-decoration: none;
}

.register-link a:hover {
    text-decoration: underline;
}
</style>
