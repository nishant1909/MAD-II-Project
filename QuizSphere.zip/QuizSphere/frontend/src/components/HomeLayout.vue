<template>
    <header>
        <nav class="navbar top-nav d-flex justify-content-between navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="logo d-flex inline-block pe-2 m-0">
                <img src="../assets/logo.png" alt="">
                <h3 class="mt-2 ms-2 text-black">QuizSphere</h3>
            </div>
            <div class="navbar-text w-25 d-flex justify-content-around">
                <router-link to="/home" class="nav-link">Home</router-link>
                <router-link to="/login" class="nav-link">Login</router-link>
                <router-link to="/user/register" class="nav-link">Register</router-link>
            </div>
        </nav>
    </header>

    <main>
        <router-view></router-view>
    </main>

    <footer>
        <p>&copy; 2025 QuizSphere. All rights reserved by Nishant Kumar.</p>
    </footer>
</template>

<script>
export default {
    name: "HomePage",
    data() {
        return {
            userRole: null,
        };
    },
    computed: {
        isAdmin() {
            return this.userRole === "admin";
        },
        isUser() {
            return this.userRole === "user";
        },
    },
    mounted() {
        // Fetch user role from token or API (example code)
        const token = localStorage.getItem("token");
        if (token) {
            const payload = JSON.parse(atob(token.split(".")[1]));
            this.userRole = payload.role;
        }
    },
};
</script>

<style scoped>
header {
    position: fixed;
    top: 0;
    width: 100%;
    background: #007bff;
    color: white;
    padding: 10px;
    text-align: center;
    z-index: 2;
}

.logo {
    border-right: 2px solid lightgray;

}

img {
    border-radius: 50%;
    width: 45px;
    height: 45px;
}

.top-nav {
    border-bottom: 2px solid lightgray;
}

.router-link-active {
    background-color: lightgrey;
    font-weight: bold;
}

main {
    padding: 20px;
}

header {
    z-index: 1000;
}

footer {
    text-align: center;
    background: #343a40;
    color: white;
    padding: 10px;
}
</style>
