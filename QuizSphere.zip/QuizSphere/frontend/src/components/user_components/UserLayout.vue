<template>
    <div class="user-layout d-flex">

        <!-- Top navbar -->
        <nav class="navbar top-nav navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="logo d-flex inline-block pe-2 m-0">
                <img src="../../assets/logo.png" alt="">
                <h3 class="mt-2 ms-2 text-black">QuizSphere</h3>
            </div>
            <button class="btn btn-light ms-3" onclick="history.back()"> &lt; Back
            </button>
            <div class="ml-auto">
                <span class="navbar-text">User Dashboard</span>
            </div>
        </nav>

        <!-- Vertical Side navbar -->
        <nav class="navbar navbar-light bg-light flex-column fixed-left sidebar text-start">
            <router-link :to="{ path: `/user/${user_id}/home` }" class="nav-link"
                :class="{ 'router-link-active': isActive(`/user/${user_id}/home`) }"
                style="margin-top: 80px;">Home</router-link>
            <router-link :to="{ path: `/user/${user_id}/profile` }" class="nav-link">Profile</router-link>
            <router-link :to="{ path: `/user/${user_id}/leaderboard` }" class="nav-link">Leaderboard</router-link>
            <router-link :to="{ path: `/user/${user_id}/scores` }" class="nav-link">Scores</router-link>
            <router-link :to="{ path: `/user/${user_id}/statistics` }" class="nav-link">Statistics</router-link>
            <!-- <router-link to="/user/leaderboard" class="nav-link">Leaderboard</router-link> -->
            <router-link to="/login" @click.prevent="logout" class="nav-link">Logout</router-link>
            <div style="height: 44.5%;"></div>
        </nav>

        <!-- Main content -->
        <main class="content p-3">
            <router-view></router-view>
        </main>

        <footer>
            <p>&copy; 2025 QuizSphere - User Dashboard. All rights reserved by Nishant Kumar.</p>
        </footer>
    </div>
</template>

<script>
export default {
    name: "UserLayout",
    props: ["user_id"],
    methods: {
        isActive(path) {
            return this.$route.path.startsWith(path);
        },

        logout() {
            localStorage.clear();
            this.$router.push("/login");
        },
    },
};
</script>

<style scoped>
.user-layout {
    font-family: Arial, Helvetica, sans-serif;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}

.router-link-active {
    background-color: lightgrey;
    font-weight: bold;
}


.top-nav {
    border-bottom: 2px solid lightgray;
}

.logo {
    border-right: 2px solid lightgray;

}

img {
    border-radius: 50%;
    width: 45px;
    height: 45px;
}

.navbar {
    padding: 10px;
    color: white;
}

.nav-link {
    margin: 0;
    padding-left: 25px;
    color: #333;
    font-size: 18px;
    width: 100%;
    color: black;
    text-decoration: none;
    font-weight: normal;
    border-radius: 5px;
    transition: background 0.3s ease;
}

.nav-link:hover {
    background: lightgrey;
}

.sidebar {
    border-right: 2px solid lightgray;
    height: 100vh;
    width: 220px;
    position: fixed;
    left: 0;
    top: 0;
}


.content {
    margin-left: 220px;
    padding-top: 60px;
}

footer {
    background: #343a40;
    color: white;
    text-align: center;
    padding: 10px;
    margin-top: auto;
}
</style>
