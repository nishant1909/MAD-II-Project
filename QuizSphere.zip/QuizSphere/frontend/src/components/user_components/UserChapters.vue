<template>
    <div class="user-chapters">
        <h2>Chapters for Subject: {{ subject_name }}</h2>

        <!-- Search Box -->
        <div class="search-box mb-3">
            <input type="text" v-model="searchQuery" @input="searchChapters" placeholder="Search chapters..."
                class="form-control" />
        </div>



        <div v-if="chapters.length === 0">
            No chapter added in this subject!
        </div>
        <div class="grid">
            <div v-for="chapter in filteredChapters" :key="chapter.chapter_id" class="card">
                <div class="img">
                    <img src="../../assets/logo.png" class="logo">
                    <img src="../../assets/chapter.jpg" class="chapter">
                </div>
                <div class="card-body text-start ms-2">
                    <h4 class="card-title">{{ chapter.chapter_name }} </h4>
                    <p class="card-text">{{ chapter.chapter_description }} </p>

                    <div class="button-column">
                        <router-link :to="{ path: `${$route.path}/${chapter.chapter_id}/quizzes` }"
                            class="btn btn-info me-2" title="View Quizzes">View
                            Quizzes</router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ["user_id", "subject_id"],
    data() {
        return {
            subject_name: "",
            searchQuery: "",
            chapters: [],
            filteredChapters: [],
        };
    },

    mounted() {
        this.fetchChapters();
    },

    methods: {
        async fetchChapters() {
            try {
                const response = await fetch(
                    `http://127.0.0.1:5000/user/${this.user_id}/home/subject/${this.subject_id}/chapters`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${localStorage.getItem("token")}`,
                        },
                    }
                );
                if (response.ok) {
                    const data = await response.json();
                    this.user = data.user;
                    this.subject_name = data.subject_name;
                    this.chapters = data.chapters || [];
                    this.filteredChapters = this.chapters;
                    console.log(this.chapters)
                } else {
                    const errorData = await response.json();
                    alert("Failed to fetch chapters: " + errorData.message);
                }
            } catch (error) {
                console.error("Error fetching chapters:", error);
            }
        },

        searchChapters() {
            const query = this.searchQuery.toLowerCase();
            this.filteredChapters = this.chapters.filter(chapter =>
                chapter.chapter_name.toLowerCase().includes(query) || chapter.chapter_description.toLowerCase().includes(query)
            );
        },

    }
}
</script>

<style scoped>
.user-chapters {
    padding: 20px;
}

.search-box {
    width: 100%;
}

.search-box input {
    margin-top: 3px;
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

.chapter {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 1%;
    border-top-right-radius: 1%;
}
</style>
