<template>
    <div class="user-scores-page">
        <div class="d-flex justify-content-between align-items-center">
            <div class="me-5"></div>
            <h2 class="ms-5">Your Scores</h2>
            <div class="d-flex align-items-end">
                <button v-if="!loading" class="btn btn-primary" @click="downloadCSV">Generate Scores
                    CSV</button>
                <p v-if="loading" class="ms-3 text-primary">Generating...</p>
            </div>
        </div>

        <!-- Search Box -->
        <div class="search-box mb-3">
            <input type="text" v-model="searchQuery" @input="filterScores"
                placeholder="Search by quiz, chapter, or subject..." class="form-control" />
        </div>

        <!-- Scores Table -->
        <div v-if="filteredScores.length === 0" class="no-data">
            No scores found.
        </div>
        <table v-else class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Subject</th>
                    <th>Chapter</th>
                    <th>Quiz</th>
                    <th>Attempted Time</th>
                    <th>Time Taken</th>
                    <th>No of Questions</th>
                    <th>Total Marks</th>
                    <th>Total Scored</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(score, index) in filteredScores" :key="score.score_id">
                    <td>{{ index + 1 }}</td>
                    <td>{{ score.subject_name }}</td>
                    <td>{{ score.chapter_name }}</td>
                    <td>{{ score.quiz_name }}</td>
                    <td>{{ formatDateTime(score.datetime_of_attempt) }}</td>
                    <td>{{ formatTime(score.time_taken) }}</td>
                    <td>{{ score.no_questions }}</td>
                    <td>{{ score.total_marks }}</td>
                    <td>{{ score.total_scored }}</td>
                </tr>
            </tbody>
        </table>
    </div>
</template>

<script>
export default {
    props: ["user_id"],
    data() {
        return {
            scores: [], // All fetched scores
            filteredScores: [], // Filtered scores based on search query
            searchQuery: "", // Search input value
            loading: false,
            task_id: null,
            interval: null,
        };
    },
    mounted() {
        this.fetchUserScores();
    },

    methods: {
        // Fetch user scores from the backend
        async fetchUserScores() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/scores`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.scores = data.scores || [];
                    this.filteredScores = this.scores;
                } else {
                    alert("Failed to fetch scores");
                }
            } catch (error) {
                console.error("Error fetching scores:", error);
            }
        },

        // Format date and time
        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },

        // Format time taken into mm:ss format
        formatTime(seconds) {
            const hrs = Math.floor(seconds / 3600); // Calculate hours
            const mins = Math.floor((seconds % 3600) / 60); // Calculate remaining minutes
            const secs = seconds % 60; // Calculate remaining seconds

            if (hrs > 0) {
                return `${hrs} hr : ${mins.toString().padStart(2, "0")} min : ${secs.toString().padStart(2, "0")} sec`;
            } else if (mins > 0) {
                return `${mins} min : ${secs.toString().padStart(2, "0")} sec`;
            } else {
                return `${secs} sec`;
            }
        },


        // Filter scores based on the search query
        filterScores() {
            const query = this.searchQuery.toLowerCase();
            this.filteredScores = this.scores.filter(
                (score) =>
                    score.quiz_name.toLowerCase().includes(query) ||
                    score.chapter_name.toLowerCase().includes(query) ||
                    score.subject_name.toLowerCase().includes(query)
            );
        },

        // Download scores CSV
        async downloadCSV() {
            this.loading = true;
            const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/export/csv`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            if (response.ok) {
                const data = await response.json();
                this.task_id = data.task_id;
                this.interval = setInterval(() => {
                    this.checkTaskStatus();
                }, 100);
            }
        },

        // Check task status
        async checkTaskStatus() {
            const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/get/csv/${this.task_id}`, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });
            if (response.ok) {
                this.loading = false;
                const contentType = response.headers.get("content-type");

                if (contentType && contentType.includes("application/json")) {
                    const data = await response.json();  // Only parse JSON if it's valid JSON

                    if (data.message === "You have not attempted any quiz yet.") {
                        alert(data.message);
                    }
                } else {
                    // If not JSON, it's a file, so open the download link
                    window.open(`http://127.0.0.1:5000/user/${this.user_id}/get/csv/${this.task_id}`, '_blank');
                }
                clearInterval(this.interval);
            } else {
                alert("Failed to download CSV");
            }
        },
    },
};
</script>

<style scoped>
.user-scores-page {
    font-family: Arial, sans-serif;
    padding: 20px;
}

h2 {
    color: #007bff;
    margin-bottom: 20px;
}

.search-box input {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.table {
    width: 100%;
    margin-top: 20px;
}

.no-data {
    text-align: center;
    color: #888;
    font-size: 1.2rem;
    margin-top: 20px;
}
</style>
