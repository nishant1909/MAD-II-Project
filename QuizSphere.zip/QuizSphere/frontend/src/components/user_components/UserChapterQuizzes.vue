<template>
    <div class="user-chapter-quizzes-page">
        <h2>Quizzes of Subject: {{ subject_name }} and Chapter: {{ chapter_name }} </h2>
    </div>

    <!-- Search Box -->
    <div class="search-box mb-3">
        <input type="text" v-model="searchQuery" @input="searchQuizzes" placeholder="Search quizzes..."
            class="form-control" />
    </div>


    <div v-if="quizzes.length === 0">
        No Quiz added in this chapter!
    </div>
    <div class="grid">
        <div v-for="quiz in filteredQuizzes" :key="quiz.quiz_id" class="card">
            <div class="img">
                <img src="../../assets/logo.png" class="logo">
                <img src="../../assets/quiz.avif" class="quiz">
            </div>
            <div class="card-body text-start ms-2">
                <h4 class="card-title text-start">{{ quiz.quiz_name }}</h4>
                <p class="card-text"><strong>Remarks: </strong> {{
                    quiz.remarks || 'No Remarks' }}</p>

                <p class="card-text"><strong>Schedule: </strong> <span v-if="quiz.quiz_schedule">Attempt
                        after {{ formatDateTime(quiz.quiz_schedule) }}</span>
                    <span v-else>Attempt Anytime</span>
                </p>
                <p class="card-text"><strong>Time Duration: </strong> {{
                    quiz.time_duration === 'No Time Limit' ? 'No Time Limit' :
                        quiz.time_duration + ' min' }}</p>

                <div class="button-column">
                    <button :disabled="isDisabled(quiz.quiz_schedule)" @click="viewQuiz(quiz)" class="btn"
                        :class="isDisabled(quiz.quiz_schedule) ? 'btn-secondary' : 'btn-info me-2'" :title="isDisabled(quiz.quiz_schedule)
                            ? `Quiz starts after ${formatDateTime(quiz.quiz_schedule)}`
                            : (quiz.attempt_status === 'Attempted' ? 'Reattempt Quiz' : 'Attempt Quiz')">
                        {{ quiz.attempt_status == 'Attempted' ? 'Reattempt Quiz' : 'Attempt Quiz' }} </button>
                </div>
            </div>
        </div>
    </div>

</template>

<script>
export default {
    props: ["user_id", "subject_id", "chapter_id"],
    data() {
        return {
            subject_name: "",
            chapter_name: "",
            searchQuery: "",
            quizzes: [],
            filteredQuizzes: [],
            minDate: new Date(new Date().getTime()).toISOString().slice(0, 16),
        };
    },
    mounted() {
        this.fetchQuizzes();
    },
    methods: {
        async fetchQuizzes() {
            try {
                const response = await fetch(
                    `http://127.0.0.1:5000/user/${this.user_id}/subject/${this.subject_id}/chapter/${this.chapter_id}/quizzes`,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `Bearer ${localStorage.getItem("token")}`,
                        },
                    }
                );
                if (response.ok) {
                    const data = await response.json();
                    this.subject_name = data.subject_name;
                    this.chapter_name = data.chapter_name;
                    this.quizzes = data.quizzes || [];
                    this.filteredQuizzes = this.quizzes;
                    console.log(this.quizzes)
                } else {
                    const errorData = await response.json();
                    alert("Failed to fetch chapters: " + errorData.message);
                }
            } catch (error) {
                console.error("Error fetching chapters:", error);
            }
        },

        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },

        searchQuizzes() {
            const query = this.searchQuery.toLowerCase();

            this.filteredQuizzes = this.quizzes.filter(quiz => {
                const scheduleStatus = quiz.quiz_schedule ? `attempt after ${this.formatDateTime(quiz.quiz_schedule)}` : "attempt anytime";
                return ((quiz.quiz_name?.toLowerCase() || "").includes(query) ||
                    (quiz.remarks?.toLowerCase() || "").includes(query) ||
                    (quiz.time_duration?.toLowerCase() || "").includes(query) ||
                    scheduleStatus.includes(query)
                );
            });
        },

        isDisabled(quiz_schedule) {
            if (!quiz_schedule) return false;
            const current_datetime = new Date();
            const quiz_datetime = new Date(quiz_schedule);
            return current_datetime < quiz_datetime;
        },

        viewQuiz(quiz) {
            if (!this.isDisabled(quiz.quiz_schedule)) {
                this.$router.push({ path: `${this.$route.path}/${quiz.quiz_id}` });
            }
        },

    }
}
</script>

<style scoped>
.user-chapter-quizzes-page {
    padding: 20px;
}

.search-box {
    width: 100%;
}

.search-box input {
    margin-top: 3px;
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.quiz {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}
</style>