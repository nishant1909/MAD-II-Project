<template>
    <div class="user-home-page">
        <main>
            <h2>User Dashboard</h2>
            <h4>Welcome, {{ user.full_name }}</h4>

            <div v-if="user.user_status === 'Inactive'" class="alert alert-danger">
                <strong>Admin Blocked You.</strong>
            </div>

            <div v-else>
                <!-- Box 1: Subjects grid -->
                <div class="box">
                    <h3 class="fw-bold">Subjects</h3>
                    <div class="d-flex mb-2">
                        <div class="search-box">
                            <input type="text" v-model="searchQuerySubject" @input="searchSubjects"
                                placeholder="Search subjects..." class="form-control" />
                        </div>
                        <div class="btn-box">
                            <router-link :to="{ path: `${$route.path}/subjects` }" class="button"
                                title="View All Subjects">View
                                All
                                Subjects</router-link>
                        </div>
                    </div>


                    <div v-if="subjects.length === 0" class="text-center">
                        No subjects available
                    </div>
                    <div v-if="filteredSubjects.length === 0" class="text-center">
                        No Subject with this Query!
                    </div>
                    <div class="grid">
                        <div v-for="subject in filteredSubjects.slice(0, 6)" :key="subject.subject_id" class="card">
                            <div class="img">
                                <img src="../../assets/logo.png" class="logo">
                                <img src="../../assets/subject.jpg" class="subject">
                            </div>
                            <div class="card-body text-start ms-2">
                                <h4 class="card-title">{{ subject.subject_name }}</h4>
                                <p class="card-text">{{ subject.subject_description }}</p>

                                <div class="button-column">
                                    <router-link
                                        :to="{ path: `${$route.path}/subjects/${subject.subject_id}/chapters` }"
                                        class="btn btn-info me-2" title="View Chapters">View
                                        Chapters</router-link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <!-- Box 2: Quizzes grid -->
                <div class="box">
                    <h3 class="fw-bold">Quizzes</h3>
                    <div class="d-flex mb-2">
                        <div class="search-box">
                            <input type="text" v-model="searchQueryQuiz" @input="searchQuizzes"
                                placeholder="Search quizzes..." class="form-control" />
                        </div>
                        <div class="btn-box">
                            <router-link :to="{ path: `${$route.path}/quizzes` }" class="button"
                                title="View All Quizzes">View
                                All Quizzes</router-link>
                        </div>
                    </div>

                    <div v-if="quizzes.length === 0" class="text-center">
                        No quizzes available
                    </div>
                    <div v-if="filteredQuizzes.length === 0">
                        No Quiz with this Query!
                    </div>
                    <div class="grid">
                        <div v-for="quiz in filteredQuizzes.slice(0, 6)" :key="quiz.quiz_id" class="card">
                            <div class="img">
                                <img src="../../assets/logo.png" class="logo">
                                <img src="../../assets/quiz.avif" class="quiz">
                            </div>
                            <div class="card-body text-start ms-2">
                                <h4 class="card-title">{{ quiz.quiz_name }}</h4>
                                <p class="card-text"><strong>Subject: </strong> {{ quiz.subject_name }}</p>
                                <p class="card-text"><strong>Chapter: </strong> {{ quiz.chapter_name }}</p>
                                <p class="card-text"><strong>Remarks: </strong> {{ quiz.remarks ||
                                    'No Remarks' }}</p>
                                <p class="card-text"><strong>Schedule: </strong> <span v-if="quiz.quiz_schedule">Attempt
                                        after {{ formatDateTime(quiz.quiz_schedule) }}</span>
                                    <span v-else>Attempt Anytime</span>
                                </p>
                                <p class="card-text"><strong>Time Duration: </strong> {{
                                    quiz.time_duration === 'No Time Limit' ? 'No Time Limit' :
                                        quiz.time_duration + ' min' }}</p>

                                <div class="button-column">
                                    <button :disabled="isDisabled(quiz.quiz_schedule)" @click="viewQuiz(quiz)"
                                        class="btn"
                                        :class="isDisabled(quiz.quiz_schedule) ? 'btn-secondary' : 'btn-info me-2'"
                                        :title="isDisabled(quiz.quiz_schedule)
                                            ? `Quiz starts after ${formatDateTime(quiz.quiz_schedule)}`
                                            : (quiz.attempt_status === 'Attempted' ? 'Reattempt Quiz' : 'Attempt Quiz')">
                                        {{ quiz.attempt_status == 'Attempted' ? 'Reattempt Quiz' : 'Attempt Quiz' }}
                                    </button>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </main>


    </div>
</template>

<script>
export default {
    props: ["user_id"],
    data() {
        return {
            user: {},
            subjects: [],
            searchQuerySubject: "",
            filteredSubjects: [],
            quizzes: [],
            searchQueryQuiz: "",
            filteredQuizzes: [],
        };
    },
    methods: {
        async fetchHome() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/home`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.user = data.user;
                    this.subjects = data.subjects || [];
                    this.filteredSubjects = this.subjects;
                    this.quizzes = data.quizzes || [];
                    this.filteredQuizzes = this.quizzes;
                } else {
                    const errorData = await response.json();
                    console.error("Failed to fetch data", errorData.msg);
                    alert("Error: " + errorData.msg);
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        },

        searchSubjects() {
            const query = this.searchQuerySubject.toLowerCase();
            this.filteredSubjects = this.subjects.filter(subject =>
                subject.subject_name.toLowerCase().includes(query) || subject.subject_description.toLowerCase().includes(query)
            );
        },

        searchQuizzes() {
            const query = this.searchQueryQuiz.toLowerCase();

            this.filteredQuizzes = this.quizzes.filter(quiz => {
                const scheduleStatus = quiz.quiz_schedule ? `attempt after ${this.formatDateTime(quiz.quiz_schedule)}` : "attempt anytime";
                return ((quiz.quiz_name?.toLowerCase() || "").includes(query) ||
                    (quiz.remarks?.toLowerCase() || "").includes(query) ||
                    (quiz.time_duration?.toLowerCase() || "").includes(query) ||
                    scheduleStatus.includes(query)
                );
            });
        },

        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },


        isDisabled(quiz_schedule) {
            if (!quiz_schedule) return false;
            const current_datetime = new Date();
            const quiz_datetime = new Date(quiz_schedule);
            return current_datetime < quiz_datetime;
        },

        viewQuiz(quiz) {
            if (!this.isDisabled(quiz.quiz_schedule)) {
                this.$router.push({ path: `${this.$route.path}/subjects/${quiz.subject_id}/chapters/${quiz.chapter_id}/quizzes/${quiz.quiz_id}` });
            }
        },



    },
    mounted() {
        this.fetchHome();
    },
};
</script>

<style scoped>
.user-home-page {
    font-family: Arial, sans-serif;
    padding: 20px;
}

h2 {
    color: #007bff;
}

.box {
    margin: 20px 0;
    padding: 20px;
    background: #f8f9fa;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.box h3 {
    margin-bottom: 10px;
    display: inline-block;
}

.search-box {
    width: 100%;
}

.search-box input {
    margin-top: 3px;
    width: 95%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.btn-box {
    width: 20%;
    margin-bottom: 10px;
    display: flex;
    justify-content: end;
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.subject {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.quiz {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

button {
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 10px;
}

.button {
    background: #007bff;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 10px;
    text-decoration: none;
}

.btn-close {
    text-emphasis-color: black;
    background: none;
}
</style>
