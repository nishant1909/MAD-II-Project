<template>

    <div class="user-statistics container mt-4">
        <h2 class="text-center text-primary">Your Quiz Statistics</h2>

        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Subjects</h5>
                    <h3 class="text-center text-primary">{{ totalSubjects }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Chapters</h5>
                    <h3 class="text-center text-primary">{{ totalChapters }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Quizzes</h5>
                    <h3 class="text-center text-primary">{{ totalQuizzes }}</h3>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Subjects Attempted</h5>
                    <h3 class="text-center text-primary">{{ totalSubjectsAttempted }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Chapters Attempted</h5>
                    <h3 class="text-center text-primary">{{ totalChaptersAttempted }}</h3>
                </div>
            </div>
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Quizzes Attempted</h5>
                    <h3 class="text-center text-primary">{{ totalQuizzesAttempted }}</h3>
                </div>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Marks</h5>
                    <h3 class="text-center text-primary">{{ totalMarks }}</h3>
                </div>
            </div>

            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Total Scored</h5>
                    <h3 class="text-center text-success">{{ totalScored }}</h3>
                </div>
            </div>

            <div class="col-4">
                <div class="card shadow p-3">
                    <h5 class="text-center">Average Score</h5>
                    <h4 class="text-center text-warning">{{ averageScore }}%</h4>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ["user_id"],
    data() {
        return {
            totalSubjects: 0,
            totalSubjectsAttempted: 0,
            totalChapters: 0,
            totalChaptersAttempted: 0,
            totalQuizzes: 0,
            totalQuizzesAttempted: 0,
            totalMarks: 0,
            totalScored: 0,
            averageScore: 0,

        };
    },
    mounted() {
        this.fetchStatistics();
    },
    methods: {
        async fetchStatistics() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/statistics`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    this.totalSubjects = data.total_subjects;
                    this.totalSubjectsAttempted = data.total_subjects_attempted;
                    this.totalChapters = data.total_chapters;
                    this.totalChaptersAttempted = data.total_chapters_attempted;
                    this.totalQuizzes = data.total_quizzes;
                    this.totalQuizzesAttempted = data.total_quizzes_attempted;
                    this.totalMarks = data.total_marks;
                    this.totalScored = data.total_score;
                    this.averageScore = data.average_score;
                    console.log(data);
                } else {
                    alert("Failed to fetch statistics");
                }
            } catch (error) {
                console.error("Error fetching statistics:", error);
            }
        },
    },
};
</script>

<style scoped>
.user-statistics {
    font-family: Arial, sans-serif;
    padding: 20px;
    border-radius: 10px;
}
</style>