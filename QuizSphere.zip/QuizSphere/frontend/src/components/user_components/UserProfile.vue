<template>
    <div class="user-profile-page">
        <h2>User Profile</h2>

        <!-- User Profile Info -->
        <div class="user-profile-info mb-4">
            <div class="text-start ms-3 mt-2 fs-3">
                <div class="mb-2"><strong>Full Name:</strong> {{ user.full_name }} </div>
                <div class="mb-2"><strong>Email:</strong> {{ user.email }} </div>
                <div class="mb-2"><strong>Date of Birth:</strong> {{ formatDate(user.dob) }} </div>
                <div><strong>Qualification:</strong> {{ user.qualification }} </div>
            </div>
        </div>
        <div>
            <div v-if="user.user_status === 'Inactive'" class="alert alert-danger">
                <strong>Admin Blocked You.</strong>
            </div>
            <div v-else>

                <button class="btn btn-warning fw-semibold" data-bs-toggle="modal"
                    data-bs-target="#editUserProfileModal" @click="assignProfile(user)" title="Edit Profile">Edit
                    Profile</button>


                <div class="modal fade" id="editUserProfileModal" tabindex="-1"
                    aria-labelledby="editUserProfileModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title ms-1" id="editUserProfileModalLabel">Edit Your Profile
                                </h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body mx-2">
                                <div class="form-floating mb-3">
                                    <input v-model="editUserData.full_name" type="text" class="form-control"
                                        id="editUserName" placeholder="Enter your full name" required>
                                    <label for="editUserName" class="form-label">Full Name</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input v-model="editUserData.dob" type="date" class="form-control" id="editUserDOB"
                                        placeholder="Enter your Date of Birth" :max="maxDate" required>
                                    <label for="editUserDOB" class="form-label">Date of Birth</label>
                                </div>
                                <div class="form-floating mb-3">
                                    <input v-model="editUserData.qualification" type="text" class="form-control"
                                        id="editUserQualification" placeholder="Enter your Qualification" required>
                                    <label for="editUserQualification" class="form-label">Qualification</label>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                    ref="cancelEditUserProfile" id="cancelEditUserProfile">Cancel</button>
                                <button type="button" class="btn btn-primary" @click="updateUserProfile">Update
                                    Changes</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ["user_id"],
    data() {
        return {
            user: {},
            editUserData: { user_id: null, full_name: "", dob: "", qualification: "" },
            maxDate: new Date().toISOString().split('T')[0],
        };
    },
    mounted() {
        this.fetchUserProfile();
    },
    methods: {
        async fetchUserProfile() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/profile`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.user = data;
                } else {
                    alert("Failed to fetch user profile");
                }
            } catch (error) {
                console.error("Error fetching user profile:", error);
            }
        },

        formatDate(dob) {
            const date = new Date(dob);
            return date.toLocaleDateString("en-GB");
        },

        assignProfile(user) {
            const formattedDob = new Date(user.dob).toISOString().split("T")[0];
            this.editUserData = {
                user_id: user.user_id,
                full_name: user.full_name,
                dob: formattedDob,
                qualification: user.qualification,
            };
            console.log(this.editUserData);
        },

        async updateUserProfile() {
            const { full_name, dob, qualification } = this.editUserData;

            if (!full_name.trim() || !dob || !qualification.trim()) {
                alert("Please fill all data.");
                return;
            }

            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/edit/profile`, {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        full_name: full_name,
                        dob: dob,
                        qualification: qualification
                    }),
                });
                if (response.ok) {
                    alert("Profile updated successfully");
                    this.fetchUserProfile();
                    document.getElementById("cancelEditUserProfile").click();
                } else {
                    const errorData = await response.json();
                    alert("Failed to update profile " + (errorData.error || errorData.message));
                }
            } catch (error) {
                console.error("Error updating user profile:", error);
            }
        },
    },
};
</script>

<style scoped>
.user-profile-page {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
}

.user-profile-info {
    border: 1px solid #ddd;
    padding: 15px;
    border-radius: 8px;
    background-color: #e9e9e9;
    box-shadow: 3px 3px 5px rgba(0, 0, 0, 0.1);
}
</style>
