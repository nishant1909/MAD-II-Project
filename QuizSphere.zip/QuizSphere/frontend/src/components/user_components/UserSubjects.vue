<template>
    <div class="user-home-subject">
        <h2>All Subjects</h2>

        <!-- Search Box -->
        <div class="search-box mb-3">
            <input type="text" v-model="searchQuery" @input="searchSubjects" placeholder="Search subjects..."
                class="form-control" />
        </div>


        <!-- Subjects Grid -->
        <div v-if="subjects.length === 0" class="text-center">
            No subjects available
        </div>
        <div v-if="filteredSubjects.length === 0" class="text-center">
            No Subject with this Query!
        </div>
        <div class="grid">
            <div v-for="subject in filteredSubjects" :key="subject.subject_id" class="card">
                <div class="img">
                    <img src="../../assets/logo.png" class="logo">
                    <img src="../../assets/subject.jpg" class="subject">
                </div>
                <div class="card-body text-start ms-2">
                    <h4 class="card-title">{{ subject.subject_name }}</h4>
                    <p class="card-text">{{ subject.subject_description }}</p>

                    <div class="button-column">
                        <router-link :to="{ path: `${$route.path}/${subject.subject_id}/chapters` }"
                            class="btn btn-info me-2" title="View Chapters">View
                            Chapters</router-link>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ["user_id"],
    data() {
        return {
            user: {},
            searchQuery: "",
            subjects: [],
            filteredSubjects: [],
        };
    },
    mounted() {
        this.fetchHome()
    },
    methods: {
        async fetchHome() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/home`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.user = data.user;
                    this.subjects = data.subjects || [];
                    this.filteredSubjects = this.subjects;
                } else {
                    const errorData = await response.json();
                    console.error("Failed to fetch Subjects", errorData.msg);
                    alert("Error: " + errorData.msg);
                }
            } catch (error) {
                console.error("Error in fetching:", error);
            }
        },

        searchSubjects() {
            const query = this.searchQuery.toLowerCase();
            this.filteredSubjects = this.subjects.filter(subject =>
                subject.subject_name.toLowerCase().includes(query) || subject.subject_description.toLowerCase().includes(query)
            );
        },
    }
};
</script>

<style scoped>
.user-home-subject {
    padding: 20px;
}

.search-box {
    width: 100%;
}

.search-box input {
    margin-top: 3px;
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.1);
}

.grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.card:hover {
    box-shadow: 0 8px 15px rgba(0, 0, 0, 0.15);
}

.img {
    position: relative;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

.subject {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}
</style>