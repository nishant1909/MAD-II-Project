<template>
    <div class="quiz-attempt-page">
        <!-- Quiz Timer -->
        <div v-if="time_left > 0 && quiz_started" class="mb-3">
            <div class="d-flex justify-content-between">
                <div class="w-75">
                    <div class="quiz-timer bg-white w-75 text-start p-2">Time Taken: {{
                        formatTime(time_taken) }}
                    </div>
                </div>
                <div class="w-25">
                    <div class="quiz-timer bg-white ms-4 w-25 p-2">Time Left: {{ formatTime(time_left)
                        }}</div>
                </div>
            </div>
        </div>

        <!-- Quiz Details -->
        <div class="quiz-details-box mb-4">
            <div class="text-start ms-3 mt-2 fs-3">
                <div class="d-flex mb-3">
                    <div class="quiz-detail"><strong>Subject:</strong> {{ quiz.subject_name }}</div>
                    <div class="quiz-detail"><strong>Chapter:</strong> {{ quiz.chapter_name }}</div>
                    <div class="quiz-detail"><strong>Quiz Name:</strong> {{ quiz.quiz_name }}</div>
                </div>
                <div class="d-flex mb-3">
                    <div style="width: 66%;"><strong>Schedule:</strong> {{ formatDateTime(quiz.quiz_schedule) ||
                        'Attempt Anytime'
                        }}</div>
                    <div class="quiz-detail"><strong>Time Duration:</strong> {{ quiz.time_duration === 'No Time Limit'
                        ? 'No Time Limit' :
                        quiz.time_duration + ' min' }}</div>
                </div>
                <div class="d-flex mb-3">
                    <div class="quiz-detail"><strong>Total Marks:</strong> {{ total_marks || 'No question' }}</div>
                    <div class="quiz-detail"><strong>Highest Score:</strong> {{ quiz.high_score }}</div>
                    <div v-if="quiz_submitted" class="quiz-detail"><strong>Currect Score:</strong> {{
                        results.total_scored }}</div>
                </div>
                <div class="mb-3"><strong>Remarks:</strong> {{ quiz.remarks || 'No Remarks' }}</div>
            </div>
        </div>


        <div v-if="questions.length === 0" class="mb-3">
            No questions are in this quiz.
        </div>
        <!-- Start Quiz Button -->
        <button v-if="!quiz_started" @click="startQuiz" class="btn btn-primary" :disabled="questions.length === 0"
            title="Start Quiz">
            Start Quiz
        </button>

        <!-- Quiz Questions -->
        <div v-if="quiz_started" class="quiz-question-container">
            <ol class="ps-0">
                <div v-for="question in questions" :key="question.question_id" class="card question-card text-start">
                    <div class="card-body ms-2">
                        <div class="d-flex">
                            <div style="width: 88%;">
                                <h4 class="card-title d-flex"><strong>Q</strong>
                                    <li style="margin-left: 3.4%;">{{ question.question_statement }}</li>
                                </h4>
                            </div>
                            <div class="ms-3" style="width: 12%;">
                                <h4 class="fw-semibold">{{ question.marks }} marks </h4>
                            </div>
                        </div>
                        <div>
                            <ol type="a" class="ms-4">
                                <h5>
                                    <input type="radio" :id="'option1' + question.question_id" value="1" class="me-2"
                                        @click="selectOption(question.question_id, 1)" :disabled="quiz_submitted"
                                        :name="question.question_id">
                                    <label :for="'option1' + question.question_id" class="ms-4"
                                        :class="getOptionClass(question, 1)">
                                        <li class="mb-2">{{ question.option1 }} </li>
                                    </label>
                                    <br>

                                    <input type="radio" :id="'option2' + question.question_id" value="2" class="me-2"
                                        @click="selectOption(question.question_id, 2)" :disabled="quiz_submitted"
                                        :name="question.question_id">
                                    <label :for="'option2' + question.question_id" class="ms-4"
                                        :class="getOptionClass(question, 2)">
                                        <li class="mb-2">{{ question.option2 }} </li>
                                    </label>
                                    <br>

                                    <input type="radio" :id="'option3' + question.question_id" value="3" class="me-2"
                                        @click="selectOption(question.question_id, 3)" :disabled="quiz_submitted"
                                        :name="question.question_id">
                                    <label :for="'option3' + question.question_id" class="ms-4"
                                        :class="getOptionClass(question, 3)">
                                        <li class="mb-2">{{ question.option3 }} </li>
                                    </label>
                                    <br>

                                    <input type="radio" :id="'option4' + question.question_id" value="4" class="me-2"
                                        @click="selectOption(question.question_id, 4)" :disabled="quiz_submitted"
                                        :name="question.question_id">
                                    <label :for="'option4' + question.question_id" class="ms-4"
                                        :class="getOptionClass(question, 4)">
                                        <li class="mb-2">{{ question.option4 }} </li>
                                    </label>
                                </h5>
                            </ol>
                        </div>
                    </div>
                </div>
            </ol>
            <!-- Submit Button -->
            <button v-if="!quiz_submitted" @click="submitQuiz" class="btn btn-success mt-3">Submit Quiz</button>
        </div>

        <!-- Quiz Results -->
        <div v-if="quiz_submitted" class="quiz-results mt-4">
            <h3>Quiz Results</h3>
            <p><strong>Current Score:</strong> {{ results.total_scored }} / {{ total_marks }}</p>
        </div>
    </div>
</template>

<script>
export default {
    props: ["user_id", "subject_id", "chapter_id", "quiz_id"],
    data() {
        return {
            quiz: {},
            questions: [],
            user_answers: {},
            quiz_started: false,
            quiz_submitted: false,
            time_left: 0,
            time_taken: 0,
            total_marks: null,
            total_scored: 0,
            timer_interval: null,
            results: {}
        };
    },
    mounted() {
        this.fetchQuizDetails();
    },
    methods: {
        async fetchQuizDetails() {
            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/subject/${this.subject_id}/chapter/${this.chapter_id}/quiz/${this.quiz_id}/details`, {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });
                if (response.ok) {
                    const data = await response.json();
                    this.quiz = data;
                    this.questions = data.questions || [];
                    this.time_left = data.time_duration * 60; // Convert minutes to seconds
                } else {
                    console.error("Failed to fetch quiz details.");
                }
            } catch (error) {
                console.error("Error fetching quiz details:", error);
            }

            this.total_marks = this.totalMarks();
        },

        startQuiz() {
            this.quiz_started = true;
            if (this.quiz.time_duration) {
                this.timer_interval = setInterval(() => {
                    if (this.time_left > 0) {
                        this.time_left--;
                        this.time_taken++;
                    } else {
                        this.submitQuiz();
                    }
                }, 1000);
            }
        },
        selectOption(question_id, option) {
            this.user_answers[question_id] = option;
        },

        totalMarks() {
            this.total_marks = 0;
            this.questions.forEach((question) => {
                this.total_marks += question.marks;
            });
            return this.total_marks;
        },

        totalScore() {
            this.questions.forEach((question) => {
                const user_answer = this.user_answers[question.question_id];
                if (user_answer === question.correct_option) {
                    this.total_scored += question.marks;
                }
            });
            return this.total_scored;
        },


        async submitQuiz() {
            clearInterval(this.timer_interval);
            this.quiz_submitted = true;
            const total_scored = this.totalScore();

            try {
                const response = await fetch(`http://127.0.0.1:5000/user/${this.user_id}/subject/${this.subject_id}/chapter/${this.chapter_id}/quiz/${this.quiz_id}/submit`, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                    body: JSON.stringify({
                        time_taken: this.time_taken,
                        total_questions: this.questions.length,
                        total_marks: this.total_marks,
                        total_scored: total_scored
                    }),
                });
                if (response.ok) {
                    const data = await response.json();
                    this.results = data;
                    this.fetchQuizDetails
                } else {
                    console.error("Failed to submit quiz.");
                }
            } catch (error) {
                console.error("Error submitting quiz:", error);
            }
        },

        formatTime(seconds) {
            const hrs = Math.floor(seconds / 3600); // Calculate hours
            const mins = Math.floor((seconds % 3600) / 60); // Calculate remaining minutes
            const secs = seconds % 60; // Calculate remaining seconds

            return `${hrs}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;

        },


        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },

        getOptionClass(question, option) {
            if (!this.quiz_submitted) return '';
            const correctOption = question.correct_option;
            const selectedOption = this.user_answers[question.question_id];

            if (option === correctOption) return 'text-success';
            if (option === selectedOption && option !== correctOption) return 'text-danger';

            return '';
        },

    }
};
</script>

<style scoped>
.quiz-attempt-page {
    padding: 20px;
    font-family: Arial, sans-serif;
}

.quiz-details-box {
    border: 1px solid #ddd;
    padding: 15px;
    border-radius: 8px;
    background-color: #e9e9e9;
    box-shadow: 3px 3px 5px rgba(0, 0, 0, 0.1);
}


.quiz-detail {
    width: 33%;
}

.quiz-timer {
    font-weight: bold;
    position: fixed;
    top: 70px;
    z-index: 100;
}

.question-card {
    margin-bottom: 15px;
    background-color: #f9f9f9;
    box-shadow: 3px 3px 5px rgba(0, 0, 0, 0.1);
}
</style>
