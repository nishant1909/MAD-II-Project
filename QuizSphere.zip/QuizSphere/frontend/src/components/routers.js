import { createRouter, createWebHistory } from "vue-router";
import HomeLayout from "./HomeLayout.vue";
import HomePage from "./HomePage.vue";
import UserLogin from "./UserLogin.vue";
import RegisterUser from "./RegisterUser.vue";
import AdminLayout from "./admin_compontents/AdminLayout.vue";
import AdminHome from "./admin_compontents/AdminHome.vue";
import AdminSubjects from "./admin_compontents/AdminSubjects.vue";
import AdminQuizzes from "./admin_compontents/AdminQuizzes.vue";
import AdminChapters from "./admin_compontents/AdminChapters.vue";
import AdminChapterQuizzes from "./admin_compontents/AdminChapterQuizzes.vue";
import AdminQuestions from "./admin_compontents/AdminQuestions.vue";
import AdminUsers from "./admin_compontents/AdminUsers.vue";
import AdminLeaderboard from "./admin_compontents/AdminLeaderboard.vue";
import AdminStatistics from "./admin_compontents/AdminStatistics.vue";
import UserLayout from "./user_components/UserLayout.vue";
import UserHome from "./user_components/UserHome.vue";
import UserSubjects from "./user_components/UserSubjects.vue";
import UserQuizzes from "./user_components/UserQuizzes.vue";
import UserChapters from "./user_components/UserChapters.vue";
import UserChapterQuizzes from "./user_components/UserChapterQuizzes.vue";
import UserQuizAttempt from "./user_components/UserQuizAttempt.vue";
import UserLeaderboard from "./user_components/UserLeaderboard.vue";
import UserStatistics from "./user_components/UserStatistics.vue";
import UserProfile from "./user_components/UserProfile.vue";
import UserScores from "./user_components/UserScores.vue";

const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: "/",
      redirect: "/home",
      name: "Home",
      component: HomeLayout,
      children: [
        {
          name: "HomePage",
          component: HomePage,
          path: "home",
        },
        {
          name: "UserLogin",
          component: UserLogin,
          path: "login",
        },
        {
          name: "RegisterUser",
          component: RegisterUser,
          path: "user/register",
        },
      ],
    },
    {
      path: "/admin",
      redirect: "/admin/home",
      component: AdminLayout,
      meta: { requiresAuth: true, role: "Admin" },
      children: [
        {
          path: "home",
          name: "AdminHome",
          component: AdminHome,
        },
        {
          path: "home/subjects",
          name: "Subjects",
          component: AdminSubjects,
        },
        {
          path: "home/quizzes",
          name: "AdminQuizzes",
          component: AdminQuizzes,
        },
        {
          path: "home/subjects/:subject_id/chapters",
          name: "AdminChapters",
          component: AdminChapters,
          props: true,
        },
        {
          path: "home/subjects/:subject_id/chapters/:chapter_id/quizzes",
          name: "AdminChapterQuizzes",
          component: AdminChapterQuizzes,
          props: true,
        },
        {
          path: "home/subjects/:subject_id/chapters/:chapter_id/quizzes/:quiz_id",
          name: "AdminQuestions",
          component: AdminQuestions,
          props: true,
        },
        {
          path: "users",
          name: "AdminUsers",
          component: AdminUsers,
        },
        {
          path: "leaderboard",
          name: "AdminLeaderboard",
          component: AdminLeaderboard,
        },
        {
          path: "statistics",
          name: "AdminStatistics",
          component: AdminStatistics,
        },
      ],
    },
    {
      path: "/user",
      component: UserLayout,
      meta: {
        requiresAuth: true,
        role: "User",
      },
      props: true,
      children: [
        {
          path: ":user_id/home",
          name: "UserHome",
          component: UserHome,
          props: true,
        },
        {
          path: ":user_id/home/subjects",
          name: "UserSubjects",
          component: UserSubjects,
          props: true,
        },
        {
          path: ":user_id/home/quizzes",
          name: "UserQuizzes",
          component: UserQuizzes,
          props: true,
        },
        {
          path: ":user_id/home/subjects/:subject_id/chapters",
          name: "UserChapters",
          component: UserChapters,
          props: true,
        },
        {
          path: ":user_id/home/subjects/:subject_id/chapters/:chapter_id/quizzes",
          name: "UserChapterQuizzes",
          component: UserChapterQuizzes,
          props: true,
        },
        {
          path: ":user_id/home/subjects/:subject_id/chapters/:chapter_id/quizzes/:quiz_id",
          name: "UserQuizAttempt",
          component: UserQuizAttempt,
          props: true,
        },
        {
          path: ":user_id/leaderboard",
          name: "UserLeaderboard",
          component: UserLeaderboard,
          props: true,
        },
        {
          path: ":user_id/profile",
          name: "UserProfile",
          component: UserProfile,
          props: true,
        },
        {
          path: ":user_id/scores",
          name: "UserScores",
          component: UserScores,
          props: true,
        },
        {
          path: ":user_id/statistics",
          name: "UserStatistics",
          component: UserStatistics,
          props: true,
        },
      ],
    },
  ],
});

// Navigation Guards
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem("token");

  // Check if the user is logged in and trying to access login or register page
  if (
    token &&
    (to.path === "/login" || to.path === "/register" || to.path === "/")
  ) {
    // Redirect logged-in users to their respective home page based on their role

    try {
      const payload = JSON.parse(atob(token.split(".")[1]));
      const userRole = payload.sub.role;

      next({ path: `/${userRole.toLowerCase()}/home` });
    } catch (error) {
      console.error("Invalid token:", error);
      next({ path: "/login" });
    }
  } else if (to.matched.some((record) => record.meta.requiresAuth)) {
    // If the route requires authentication and no token exists
    if (!token) {
      next({ path: "/login" });
    } else {
      try {
        const payload = JSON.parse(atob(token.split(".")[1]));
        console.log("Decoded payload:", payload); // Log the full payload

        const status = localStorage.getItem("status");

        const payloadUserId = payload.sub.user;

        // Extract user_id from the URL
        const urlUserId = to.params.user_id;

        // Directly access role from the payload
        const userRole = payload.sub.role;
        const userId = payload.sub.user;
        console.log("User role:", userRole); // Log user role
        console.log("UserID:", userId); // Log userid

        if (to.meta.role && to.meta.role !== userRole) {
          alert("Access denied!");
          next({ path: `/${userRole.toLowerCase()}/home` });
        } else if (urlUserId && urlUserId !== payloadUserId.toString()) {
          alert("Access denied: User ID mismatch!");
          next({ path: `/${userRole.toLowerCase()}/${payloadUserId}/home` });
        } else if (status == "Inactive" && !to.path.endsWith("/home")) {
          alert("You are blocked by Admin. You can relogin to check.");
          next({ path: `/${userRole.toLowerCase()}/${payloadUserId}/home` });
        } else {
          next();
        }
      } catch (error) {
        console.error("Invalid token:", error);
        next({ path: "/login" });
      }
    }
  } else {
    next();
  }
});

export default router;
