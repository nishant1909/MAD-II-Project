<template>
    <div class="home-page">
        <!-- Image Slideshow -->
        <div class="slideshow-container mb-3 border">
            <div class="image-container d-flex">
                <img src="../assets/logo.png" class="slide-image" alt="Slideshow Image 1" />
                <img src="../assets/subject.jpg" class="slide-image" alt="Slideshow Image 2" />
                <img src="../assets/chapter.jpg" class="slide-image" alt="Slideshow Image 3" />
                <img src="../assets/quiz.avif" class="slide-image" alt="Slideshow Image 4" />
            </div>
        </div>

        <hr>

        <div class="box">
            <!-- Subjects Grid -->
            <h2>Subjects</h2>
            <div v-if="subjects.length === 0" class="text-center">
                No subjects available
            </div>
            <div class="grid overflow-y-auto pt-2" style="height: 575px;">
                <div v-for="subject in subjects" :key="subject.subject_id" class="card">
                    <div class="img">
                        <img src="../assets/logo.png" class="logo">
                        <img src="../assets/subject.jpg" class="subject">
                    </div>
                    <div class="card-body text-start ms-2">
                        <h4 class="card-title">{{ subject.subject_name }}</h4>
                        <p class="card-text">{{ subject.subject_description }}</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="box">
            <!-- Chapters Grid -->
            <h2>Chapters</h2>
            <div v-if="chapters.length === 0" class="text-center">
                No Chapters available
            </div>
            <div class="grid overflow-y-auto pt-2" style="height: 649px;">
                <div v-for="chapter in chapters" :key="chapter.chapter_id" class="card">
                    <div class="img">
                        <img src="../assets/logo.png" class="logo">
                        <img src="../assets/chapter.jpg" class="chapter">
                    </div>
                    <div class="card-body text-start ms-2">
                        <h4 class="card-title">{{ chapter.chapter_name }} </h4>
                        <p class="card-text">{{ chapter.chapter_description }} </p>
                        <p class="card-text"><strong>Subject:</strong> {{ chapter.subject_name }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quizzes Grid -->
        <div class="box">
            <h2>Quizzes</h2>
            <div v-if="quizzes.length === 0" class="text-center">
                No quizzes available
            </div>
            <div class="grid overflow-y-auto pt-2" style="height: 1000px;">
                <div v-for="quiz in quizzes" :key="quiz.quiz_id" class="card">
                    <div class="img">
                        <img src="../assets/logo.png" class="logo">
                        <img src="../assets/quiz.avif" class="quiz">
                    </div>
                    <div class="card-body text-start ms-2">
                        <h4 class="card-title">{{ quiz.quiz_name }}</h4>
                        <p class="card-text"><strong>Subject: </strong> {{ quiz.subject_name }}</p>
                        <p class="card-text"><strong>Chapter: </strong> {{ quiz.chapter_name }}</p>
                        <p class="card-text"><strong>Remarks: </strong> {{ quiz.remarks ||
                            'No Remarks' }}</p>
                        <p class="card-text"><strong>Schedule: </strong> <span v-if="quiz.quiz_schedule">Attempt
                                after {{ formatDateTime(quiz.quiz_schedule) }}</span>
                            <span v-else>Attempt Anytime</span>
                        </p>
                        <p class="card-text"><strong>Time Duration: </strong> {{
                            quiz.time_duration === 'No Time Limit' ? 'No Time Limit' :
                                quiz.time_duration + ' min' }}</p>

                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            subjects: [],
            chapters: [],
            quizzes: [],
        };
    },
    mounted() {
        this.fetchData();
    },
    methods: {
        async fetchData() {
            try {
                const response = await fetch("http://127.0.0.1:5000/", {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        // Authorization: `Bearer ${localStorage.getItem("token")}`,
                    },
                });

                if (response.ok) {
                    const data = await response.json();
                    this.subjects = data.subjects;
                    this.chapters = data.chapters;
                    this.quizzes = data.quizzes;
                } else {
                    console.error("Failed to fetch data");
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        },

        formatDateTime(dateTime) {
            const date = new Date(dateTime);
            return date.toLocaleString("en-GB", {
                day: "2-digit",
                month: "2-digit",
                year: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: true,
            });
        },
    },
};
</script>

<style scoped>
/* Page Layout */
.home-page {
    padding: 20px;
    text-align: center;
}

/* Slideshow */
.slideshow-container {
    width: 100%;
    height: 400px;
    overflow: hidden;
    background: #f8f9fa;
    margin-top: -26px;
}

.image-container {
    width: 100%;
    height: 100%;
    animation: slide 10s linear infinite;
}

.slide-image {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 10px;
}

@keyframes slide {
    0% {
        transform: translateX(0);
    }

    15% {
        transform: translateX(0);
    }

    50% {
        transform: translateX(-60%);
    }

    75% {
        transform: translateX(-120%);
    }


    100% {
        transform: translateX(-180%);
        /* Move by 2 image widths */
    }
}


.box {
    margin: 20px 0;
    padding: 20px;
    background: #f8f9fa;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 15px;
}

.img {
    position: relative;
}

.logo {
    position: absolute;
    top: 5px;
    left: 5px;
    width: 25%;
    height: 40%;
    border-radius: 50%;
}

.subject {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}

.chapter {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 1%;
    border-top-right-radius: 1%;
}

.quiz {
    width: 100%;
    height: auto;
    border-bottom: 1px solid rgb(249, 246, 246);
    border-top-left-radius: 2%;
    border-top-right-radius: 2%;
}
</style>
