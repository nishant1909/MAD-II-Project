from celery.schedules import crontab
from datetime import datetime
from .tasks import send_daily_reminders, send_monthly_activity_report


def setup_periodic_tasks(sender, **kwargs):
    sender.add_periodic_task(
        crontab(hour=18, minute=0),
        send_daily_reminders.s(),
        name='send-daily-reminders'
    )
    
    sender.add_periodic_task(
        crontab(day_of_month=1, hour=9, minute=0),
        send_monthly_activity_report.s(),
        name='send-monthly-activity-report'
    )


