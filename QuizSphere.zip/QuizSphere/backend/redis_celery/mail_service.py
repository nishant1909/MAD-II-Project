import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from ..config import Config


def send_mail(to, subject, body):
    try:
        msg = MIMEMultipart()
        msg['From'] = Config.SENDER_EMAIL
        msg['To'] = to
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'html'))
        
        with smtplib.SMTP(host=Config.SMTP_SERVER, port=Config.SMTP_PORT) as client:
            # Removed TLS since MailHog doesn't use it
            client.send_message(msg)
            print(f"Email sent successfully to {to}")
            client.quit()
    except Exception as e:
        print(f"Failed to send email: {str(e)}")

# send_mail("dsf@email.com", "Test Email", "<h1>This is a test email</h1>")