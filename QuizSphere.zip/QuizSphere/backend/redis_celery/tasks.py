from celery import shared_task
import time
from ..model import db, User, Subject, Chapter, Quiz, Score
import csv
import os
from .mail_service import send_mail
from datetime import datetime

@shared_task(ignore_result=False)
def add(x, y):
    return x+y


# Create exports directory if it doesn't exist
export_dir = 'backend/exports'
if not os.path.exists(export_dir):
    os.makedirs(export_dir)

@shared_task(ignore_result=False)
def generate_user_quiz_csv(user_id):
    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return f"User from User ID {user_id} not found."
    
    scores = Score.query.filter_by(user_id=user_id).all()
    if not scores:
        return "You have not attempted any quiz yet."
    
    column_names = ["S.No", "Quiz Name", "Subject Name", "Chapter Name", "Attempted On", "Total Marks of Quiz", "Obtained Marks", "Remarks"]
    user_quiz_data = []
    
    count = 1

    for score in scores:
        quiz = Quiz.query.filter_by(quiz_id=score.quiz_id).first()
        chapter = Chapter.query.filter_by(chapter_id=quiz.chapter_id).first()
        subject = Subject.query.filter_by(subject_id=chapter.subject_id).first()
        
        if (score.total_scored > (score.total_marks*0.75)):
            remark = "Well Done"
        elif (score.total_scored > (score.total_marks*0.50)):
            remark = "Good"
        elif (score.total_scored > (score.total_marks*0.30)):
            remark = "Need Improvement"
        else:
            remark = "Need to work hard"
        
        user_quiz_data.append([
            count,
            quiz.quiz_name,
            subject.name,
            chapter.name,
            score.datetime_of_attempt.strftime("%d/%m/%Y %H:%M:%S"),
            score.total_marks,
            score.total_scored,
            remark
        ])
        count += 1
        
    file_path = f"{export_dir}/user_{user_id}_quiz_data.csv"
    with open(file_path, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(column_names)
        writer.writerows(user_quiz_data)
    
    return file_path


@shared_task(ignore_result=False)
def generate_admin_quiz_csv():
    users = User.query.filter(User.email != 'n4nishantkumar2004@gmail.com').all()
    if not users:
        return "No users found"
    
    column_names = ["S.No", "Full Name", "Email", "Qualification", "Date of Birth", "Status", "No. of Quizzes Attempted", "Total Marks Obtained", "Average Score", "Remarks"]
    admin_quiz_data = []

    count = 1

    for user in users:
        scores = Score.query.filter_by(user_id=user.user_id).all()
        if not scores:
            admin_quiz_data.append([
                count,
                user.full_name,
                user.email,
                user.qualification,
                user.dob.strftime("%d/%m/%Y"),
                user.status if user.status == 'Active' else 'Blocked',
                "No Quiz Attempted",
                "0",
                "0",
                "No Remarks"
            ])
            count += 1
            continue
        
        
        distinct_quiz_count = len(set(score.quiz_id for score in scores))
        total_marks = sum(score.total_marks for score in scores)
        total_scored = sum(score.total_scored for score in scores)

        if distinct_quiz_count == 0:
            average = 0
        else:
            average = round(total_scored / distinct_quiz_count, 2)

        if total_scored > (total_marks*0.75):
            remarks = "Excellent"
        elif total_scored > (total_marks*0.50):
            remarks = "Good"
        elif total_scored > (total_marks*0.30):
            remarks = "Need Improvement"
        else:
            remarks = "Need to work hard"
        
        admin_quiz_data.append([
            count,
            user.full_name,
            user.email,
            user.qualification,
            user.dob.strftime("%d/%m/%Y"),
            user.status if user.status == 'Active' else 'Blocked',
            distinct_quiz_count,
            total_scored,
            average,
            remarks
        ])
        count += 1
    file_path = f"{export_dir}/admin_quiz_data.csv"
    with open(file_path, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(column_names)
        writer.writerows(admin_quiz_data)
    
    return file_path

@shared_task(ignore_result=True)
def send_daily_reminders():
    users = User.query.filter(User.email != 'n4nishantkumar2004@gmail.com').all()
    if not users:
        return "No users found"
    
    for user in users:
        last_login = user.last_login or datetime(2000,1,1)
        new_quizzes = Quiz.query.filter(Quiz.created_at > last_login).count()

        if new_quizzes > 0:
            send_mail(user.email, "Daily Reminder for New Quizzes Available!", f"<p>Hey! {user.full_name}, new quizzes are added on app, you should attempt to EMPOWER YOUR KNOWLEDGE JOURNEY!</p>")

    return "Daily reminders sent successfully."

@shared_task(ignore_result=True)
def send_monthly_activity_report():
    users = User.query.filter(User.email != 'n4nishantkumar2004@gmail.com').all()
    if not users:
        return "No users found"
    
    for user in users:
        scores = Score.query.filter_by(user_id=user.user_id).all()
        if not scores:
            send_mail(user.email, "Monthly Activity Report", f"<p>Hey! {user.full_name}, you have not attempted any quiz yet.</p>")
            continue
        
        max_scores_in_quiz = {}
        quiz_data = []
        count = 1
        for score in scores:
            if score.quiz_id not in max_scores_in_quiz or max_scores_in_quiz[score.quiz_id] < score.total_scored:
                max_scores_in_quiz[score.quiz_id] = score.total_scored
                
            quiz = Quiz.query.filter_by(quiz_id=score.quiz_id).first()
            chapter = Chapter.query.filter_by(chapter_id=quiz.chapter_id).first()
            subject = Subject.query.filter_by(subject_id=chapter.subject_id).first()

            quiz_data.append({
                "s_no": count,
                "quiz_name": quiz.quiz_name,
                "subject_name": subject.name,
                "chapter_name": chapter.name,
                "datetime_of_attempt": score.datetime_of_attempt.strftime("%d/%m/%Y %H:%M:%S"),
                "time_duration": quiz.time_duration,
                "time_taken": score.time_taken,
                "total_marks": score.total_marks,
                "total_scored": score.total_scored
            })
            count += 1
        total_obtained_scored = sum(max_scores_in_quiz.values())
        distinct_quiz_count = len(max_scores_in_quiz)
        
        if distinct_quiz_count == 0:
            average = 0
        else:
            average = round(total_obtained_scored / distinct_quiz_count, 2)
        
        html_content = f"""
        <html>
        <body>
        <head>
        <style>
        body {{
            font-family: Arial, sans-serif;
            margin: 20px;
            padding: 20px;
            background-color: #f8f9fa;
            color: #333;
        }}
        h1 {{
            color: #2c3e50;
            text-align: center;
        }}
        p {{
            font-size: 16px;
            line-height: 1.6;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            overflow: hidden;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }}
        th {{
            background-color: #3498db;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }}
        tr:nth-child(even) {{
            background-color: #f2f2f2;
        }}
        tr:hover {{
            background-color: #d6eaf8;
        }}
        .footer {{
            text-align: center;
            font-style: italic;
            margin-top: 20px;
            color: #555;
        }}
        </style>
        </head>
        <body>
        <h1>Monthly Activity Report</h1>
        <p>Hello {user.full_name},</p>
        
        <p>Here is your quiz performance for this month:</p>
        
        <p><strong>Total Quizzes Attempted:</strong> {distinct_quiz_count}</p>
        <p><strong>Average Score:</strong> {average}%</p>
        
        <h3>Quiz Details:</h3>
        <table>
            <tr>
                <th>S.No</th>
                <th>Subject</th>
                <th>Chapter</th>
                <th>Quiz Name</th>
                <th>Attempted On</th>
                <th>Quiz Time Duration</th>
                <th>Time Taken</th>
                <th>Total Marks</th>
                <th>Obtained Marks</th>
            </tr>"""
            
        for quiz in quiz_data:
            html_content += f"""
            <tr>
                <td>{quiz["s_no"]}</td>
                <td>{quiz["subject_name"]}</td>
                <td>{quiz["chapter_name"]}</td>
                <td>{quiz["quiz_name"]}</td>
                <td>{quiz["datetime_of_attempt"]}</td>
                <td>{quiz["time_duration"]}</td>
                <td>{quiz["time_taken"]}</td>
                <td>{quiz["total_marks"]}</td>
                <td>{quiz["total_scored"]}</td>
            </tr>"""
            
        html_content += """
        </table>
        <p class="footer">Keep improving and best of luck for your future quizzes! 🚀</p>
        </body>
        </html>
        """
        
        send_mail(user.email, "Monthly Activity Report", html_content)
        
    return "Monthly reports sent successfully."
