# from flask import Flask
# from flask_sqlalchemy import SQLAlchemy
# from flask_jwt_extended import JWTManager
# from flask_migrate import Migrate
# from flask_mail import Mail


# # Extensions
# db = SQLAlchemy()
# jwt = JWTManager()
# migrate = Migrate()
# mail = Mail()

# def create_app():
#     app = Flask(__name__)
#     app.config.from_object('config.Config')

#     # Initialize extensions
#     db.init_app(app)
#     jwt.init_app(app)
#     migrate.init_app(app, db)
#     mail.init_app(app)

#     # Register blueprints
#     from .routes import routes_bp
#     from .admin_routes import admin_bp
#     from .user_routes import user_bp
    
#     app.register_blueprint(routes_bp, url_prefix='/')
#     app.register_blueprint(admin_bp, url_prefix='/admin')
#     app.register_blueprint(user_bp, url_prefix='/user')

#     return app
