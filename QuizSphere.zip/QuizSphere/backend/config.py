from datetime import timedelta

class Config:
    SECRET_KEY = '737jgr38aTpibfiTgFXbjTuZ2tXAwVoiDGmFz9gP9fc'
    
    # Database Configuration
    SQLALCHEMY_DATABASE_URI = 'sqlite:///QuizSphere.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # JWT Configuration
    JWT_SECRET_KEY = "68209520318433206527309096085426102451"
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=5)
    
    # Mail Configuration
    SMTP_SERVER = 'localhost'
    SMTP_PORT = 1025
    SENDER_EMAIL = 'nishant@email.com'
    SENDER_PASSWORD = '!@12Nishant34#$'
    
    # Flask-Caching (Redis)
    CACHE_TYPE = "RedisCache"
    CACHE_REDIS_HOST = "localhost"
    CACHE_REDIS_PORT = 6379
    CACHE_DEFAULT_TIMEOUT = 50

    # Celery Configuration
    CELERY = {
        'broker_url': 'redis://localhost:6379/0',
        'result_backend': 'redis://localhost:6379/0',
        'timezone': 'Asia/Kolkata'
    }
