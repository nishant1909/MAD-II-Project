from flask import Blueprint, jsonify, request
from flask_jwt_extended import create_access_token
from werkzeug.security import generate_password_hash, check_password_hash
from backend.model import db, User, Subject, Chapter, Quiz
from flask_caching import Cache
from datetime import datetime

routes_bp = Blueprint('routes', __name__)
cache_instance = Cache()



# Health Check Route
@routes_bp.route('/', methods=['GET'])
@cache_instance.memoize(timeout=120)
def home():
    subjects = Subject.query.filter_by(status='Active').all()
    subjects_data = [{
        'subject_id': subject.subject_id,
        'subject_name': subject.name,
        'subject_description': subject.description
    } for subject in subjects]

    # Query for subjects, chapters, and quizzes
    joined_table = Subject.query.join(Chapter, Chapter.subject_id == Subject.subject_id).join(Quiz, Quiz.chapter_id == Chapter.chapter_id).filter(Chapter.status == 'Active').filter(Quiz.status == 'Active').all()

    # Prepare data for chapters and quizzes
    chapters_data = []
    quizzes_data = []

    for subject in joined_table:
        for chapter in subject.chapter:
            # Add chapter data
            chapters_data.append({
                'chapter_id': chapter.chapter_id,
                'chapter_name': chapter.name,
                'chapter_description': chapter.description,
                'subject_id': subject.subject_id,
                'subject_name': subject.name
            })
            
            for quiz in chapter.quiz:
                # Add quiz data
                quizzes_data.append({
                    'quiz_id': quiz.quiz_id,
                    'quiz_name': quiz.quiz_name,
                    'quiz_schedule': quiz.quiz_schedule,
                    'time_duration': quiz.time_duration,
                    'remarks': quiz.remarks,
                    'subject_id': subject.subject_id,
                    'subject_name': subject.name,
                    'chapter_id': chapter.chapter_id,
                    'chapter_name': chapter.name
                })

    return jsonify({
        'subjects': subjects_data,
        'chapters': chapters_data,
        'quizzes': quizzes_data
    }), 200



# User/Admin Login
@routes_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()
    if not user:
        return jsonify({'error': 'Not Registered'}), 404
    elif not check_password_hash(user.password, data['password']):
        return jsonify({'error': 'Invalid email or password'}), 401

    if user.role == 'User':
        # Update last login timestamp
        user.last_login = datetime.now()
        db.session.commit()

    # Create token with additional claims (role and email)
    access_token = create_access_token(
        identity={'user':user.user_id,
            'email': user.email,
            'role': user.role
        }
    )

    return jsonify({
        'message': 'Logged in successfully',
        'token': access_token,
        'user': {
            'user_id': user.user_id,
            'email': user.email,
            'full_name': user.full_name,
            'qualification': user.qualification,
            'dob': user.dob,
            'role': user.role,
            'status': user.status
        }
    })


# Fallback Route for 404 Errors
@routes_bp.app_errorhandler(404)
def not_found_error(error):
    return jsonify({'error': 'Resource not found'}), 404

# Fallback Route for 500 Errors
@routes_bp.app_errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500
