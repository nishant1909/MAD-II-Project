from flask import Blueprint, request, jsonify, session, send_file
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash
from backend.model import db, User, Subject, Chapter, Quiz, Question, Score
from datetime import datetime
from ..redis_celery.tasks import generate_user_quiz_csv, add
from celery.result import AsyncResult
from io import BytesIO
import os
from flask_caching import Cache

user_bp = Blueprint('user', __name__)
cache_instance = Cache()

# Helper Function to Check User Role
def is_user():
    current_user = get_jwt_identity()
    return current_user.get('role') == 'User'


@user_bp.route('/celery/status/<task_id>', methods=['GET'])
def celery_data(task_id):
    task = AsyncResult(task_id)
    
    if task.ready():
        return jsonify({'message': 'Task completed', 'result': task.result}), 200
    else:
        return jsonify({'message': 'Task not completed', 'status': task.status}), 405

# User Register
@user_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()

    # Convert 'dob' string to Python date object
    dob = None
    if 'dob' in data and data['dob']:
        try:
            dob = datetime.strptime(data['dob'], '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD.'}), 400

    # Hash password
    hashed_password = generate_password_hash(data['password'])

    # Create new user object
    new_user = User(
        email=data['email'],
        password=hashed_password,
        full_name=data.get('full_name'),
        qualification=data.get('qualification'),
        dob=dob,
        status='Active'
    )
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'User registered successfully'}), 201


@user_bp.route('/<int:user_id>/home', methods=['GET'])
@jwt_required()
@cache_instance.memoize(timeout=120)
def user_home(user_id):
    
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403
    
    user=User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user_data = {
        'user_id': user.user_id,
        'email': user.email,
        'full_name': user.full_name,
        'qualification': user.qualification,
        'dob': user.dob,
        'role': user.role,
        'user_status': user.status
    }

    subject_list = Subject.query.filter_by(status='Active').all()
    if not subject_list:
        return jsonify({'error': 'Subject not found'}), 404
    subjects = [{'subject_id': subject.subject_id, 'subject_name': subject.name, 'subject_description': subject.description } for subject in subject_list]
    
    joined_table = Subject.query.join(Chapter, Chapter.subject_id == Subject.subject_id).join(Quiz, Quiz.chapter_id == Chapter.chapter_id).filter(Quiz.status == 'Active').all()
    quizzes = []
    for subject in joined_table:
        for chapter in subject.chapter:
            for quiz in chapter.quiz:
                score = Score.query.filter_by(user_id=user_id, quiz_id=quiz.quiz_id).first()
                if score:
                    attempt_status = 'Attempted'
                else:
                    attempt_status = 'Not Attempted'
                quizzes.append({
                    'quiz_id': quiz.quiz_id,
                    'quiz_name': quiz.quiz_name,
                    'quiz_schedule': quiz.quiz_schedule,
                    'time_duration': quiz.time_duration,
                    'remarks': quiz.remarks,
                    'subject_id': subject.subject_id,
                    'subject_name': subject.name,
                    'chapter_id': chapter.chapter_id,
                    'chapter_name': chapter.name,
                    'attempt_status': attempt_status
                })
    return jsonify({'user': user_data, 'subjects': subjects, 'quizzes': quizzes}), 200

# Choose Chapter
@user_bp.route('/<int:user_id>/home/subject/<int:subject_id>/chapters', methods=['GET'])
@jwt_required()
@cache_instance.memoize(timeout=120)
def get_chapters(user_id, subject_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403
    
    user=User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user_data = {
        'user_id': user.user_id,
        'email': user.email,
        'full_name': user.full_name,
        'qualification': user.qualification,
        'dob': user.dob,
        'role': user.role
    }
    
    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404

    chapters = Chapter.query.filter_by(subject_id=subject_id, status='Active').all()
    if not chapters:
        return jsonify({ 'user': user_data, 'subject_id':subject.subject_id, 'subject_name': subject.name, 'message': 'No chapters available for this subject'}), 200
    
    chapters_list = [{'chapter_id': chapter.chapter_id, 'chapter_name': chapter.name, 'chapter_description': chapter.description } for chapter in chapters]
    
    return jsonify({ 'user': user_data, 'subject_id':subject.subject_id, 'subject_name': subject.name, 'chapters': chapters_list}), 200


# Start Quiz
@user_bp.route('/<int:user_id>/subject/<int:subject_id>/chapter/<int:chapter_id>/quizzes', methods=['GET'])
@jwt_required()
def get_quizzes(user_id, subject_id, chapter_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403

    user=User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user_data = {
        'user_id': user.user_id,
        'email': user.email,
        'full_name': user.full_name,
        'qualification': user.qualification,
        'dob': user.dob,
        'role': user.role
    }
    
    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404

    chapter = Chapter.query.filter_by(subject_id=subject_id).first()
    if not chapter:
        return jsonify({'error': 'Chapter not found'}), 404
    
    quizzes = Quiz.query.filter_by(chapter_id=chapter_id, status='Active').all()
    if not quizzes:
        return jsonify({ 'user': user_data, 'subject_id': subject.subject_id, 'subject_name': subject.name, 'chapter_id':chapter.chapter_id, 'chapter_name': chapter.name, 'message': 'No quizzes available for this chapter'}), 200
    
    quiz_list = []
    for quiz in quizzes:
        score = Score.query.filter_by(user_id=user_id, quiz_id=quiz.quiz_id).first()
        if score:
            attempt_status = 'Attempted'
        else:
            attempt_status = 'Not Attempted'
            
        quiz_list.append({
            'quiz_id': quiz.quiz_id,
            'quiz_name': quiz.quiz_name,
            'quiz_schedule': quiz.quiz_schedule,
            'time_duration': quiz.time_duration,
            'remarks': quiz.remarks,
            'attempt_status': attempt_status
        })
    
    
    return jsonify({'user': user_data,'subject_id':subject.subject_id, 'subject_name': subject.name, 'chapter_id':chapter.chapter_id, 'chapter_name': chapter.name, 'quizzes': quiz_list}), 200

@user_bp.route('/<int:user_id>/subject/<int:subject_id>/chapter/<int:chapter_id>/quiz/<int:quiz_id>/details', methods=['GET'])
@jwt_required()
@cache_instance.memoize(timeout=300)
def get_quiz_details(user_id, subject_id, chapter_id, quiz_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403
    
    user=User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    user_data = {
        'user_id': user.user_id,
        'email': user.email,
        'full_name': user.full_name,
        'qualification': user.qualification,
        'dob': user.dob,
        'role': user.role
    }
    
    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404

    chapter = Chapter.query.filter_by(subject_id=chapter_id).first()
    if not chapter:
        return jsonify({'error': 'Chapter not found'}), 404
    
    quiz = Quiz.query.filter_by(quiz_id=quiz_id).first()
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    
    scores = Score.query.filter_by(quiz_id=quiz_id).all()
    if len(scores) == 0:
        high_score=0
    else:
        scores.sort(key=lambda score: score.total_scored)
        high_score = scores[-1].total_scored

    questions = Question.query.filter_by(quiz_id=quiz_id).all()
    questions_data = [
        {
            'question_id': question.question_id,
            'question_statement': question.question_statement,
            'marks': question.marks,
            'option1': question.option1,
            'option2': question.option2,
            'option3': question.option3,
            'option4': question.option4,
            'correct_option': question.correct_option,
        } for question in questions
    ]

    return jsonify({
        'user': user_data,
        'subject_name': subject.name,
        'chapter_name': chapter.name,
        'quiz_name': quiz.quiz_name,
        'quiz_schedule': quiz.quiz_schedule,
        'time_duration': quiz.time_duration,
        'high_score': high_score,
        'remarks': quiz.remarks,
        'questions': questions_data
    }), 200


# Submit Quiz

@user_bp.route('/<int:user_id>/subject/<int:subject_id>/chapter/<int:chapter_id>/quiz/<int:quiz_id>/submit', methods=['POST'])
@jwt_required()
def submit_quiz(user_id, subject_id, chapter_id, quiz_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403
    
    user=User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    
    quiz = Quiz.query.filter_by(quiz_id=quiz_id).first()
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404

    data = request.get_json()
    
    time_taken = data.get('time_taken')
    total_questions=data.get('total_questions')
    total_marks = data.get('total_marks')
    total_scored = data.get('total_scored')
    
    

    # Store attempt details in the database
    score = Score(
        quiz_id=quiz_id,
        user_id=user_id,
        datetime_of_attempt = datetime.now(),
        time_taken = time_taken,
        no_questions = total_questions,
        total_marks = total_marks,
        total_scored = total_scored 
    )
    db.session.add(score)
    db.session.commit()

    return jsonify({
        'total_scored': total_scored,
        'total_questions': total_questions
    }), 200


# Leaderboard
@user_bp.route('/leaderboard', methods=['GET'])
@jwt_required()
@cache_instance.cached(timeout=60, key_prefix='leaderboard_cache')
def leaderboard():
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403
    
    users_list = User.query.filter(User.email != 'n4nishantkumar2004@gmail.com').all()
    
    users = [ { 'user_id': user.user_id, 'email': user.email, 'full_name': user.full_name, 'qualification': user.qualification, 'dob': user.dob, 'status': user.status} for user in users_list]
    
    score_list = Score.query.all()
    
    scores = [ { 'score_id': score.score_id, 'quiz_id': score.quiz_id, 'user_id': score.user_id, 'total_scored': score.total_scored } for score in score_list]
    
    return jsonify({ 'users': users, 'scores': scores}), 200


# Fetch User Profile
@user_bp.route('/<int:user_id>/profile', methods=['GET'])
@jwt_required()
def get_user_profile(user_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403

    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    return jsonify({
        'user_id': user.user_id,
        'full_name': user.full_name,
        'email': user.email,
        'dob': user.dob,
        'qualification': user.qualification,
        'user_status': user.status
    }), 200


# Update User Profile
@user_bp.route('/<int:user_id>/edit/profile', methods=['PUT'])
@jwt_required()
def update_user_profile(user_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403

    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    data = request.get_json()
    
    dob = data.get('dob')
    if dob:
        dob = datetime.strptime(data['dob'], '%Y-%m-%d').date()
    else:
        return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD.'}), 400


    user.full_name = data.get('full_name')
    user.dob = dob
    user.qualification = data.get('qualification')

    db.session.commit()

    return jsonify({'message': 'Profile updated successfully'}), 200


@user_bp.route('/<int:user_id>/scores', methods=['GET'])
@jwt_required()
@cache_instance.memoize(timeout=30)
def get_user_scores(user_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403

    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    # scores = (
    #     db.session.query(Score, Quiz, Chapter, Subject)
    #     .join(Quiz, Score.quiz_id == Quiz.quiz_id)
    #     .join(Chapter, Quiz.chapter_id == Chapter.chapter_id)
    #     .join(Subject, Chapter.subject_id == Subject.subject_id)
    #     .filter(Score.user_id == user_id)
    #     .all()
    # )

    # scores_data = []
    # for score, quiz, chapter, subject in scores:
    #     scores_data.append({
    #         'score_id': score.score_id,
    #         'datetime_of_attempt': score.datetime_of_attempt,
    #         'time_taken': score.time_taken,
    #         'no_questions': score.no_questions,
    #         'total_marks': score.total_marks,
    #         'total_scored': score.total_scored,
    #         'quiz_name': quiz.quiz_name,
    #         'chapter_name': chapter.name,
    #         'subject_name': subject.name,
    #     })
    
    scores = Score.query.filter_by(user_id=user_id).all()
    scores_data = []
    for score in scores:
        quiz = Quiz.query.filter_by(quiz_id=score.quiz_id).first()
        chapter = Chapter.query.filter_by(chapter_id=quiz.chapter_id).first()
        subject = Subject.query.filter_by(subject_id=chapter.subject_id).first()
        
        scores_data.append({
            'score_id': score.score_id,
            'datetime_of_attempt': score.datetime_of_attempt,
            'time_taken': score.time_taken,
            'no_questions': score.no_questions,
            'total_marks': score.total_marks,
            'total_scored': score.total_scored,
            'quiz_name': quiz.quiz_name,
            'chapter_name': chapter.name,
            'subject_name': subject.name,
        })
    

    return jsonify({'scores': scores_data}), 200

@user_bp.route('/<int:user_id>/statistics', methods=['GET'])
@jwt_required()
@cache_instance.memoize(timeout=30)
def user_statistics(user_id):
    """Returns statistics for a given user."""
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403

    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    # Fetch statistics
    scores = Score.query.filter_by(user_id=user_id).all()
    max_score_in_quiz = {}
    for score in scores:
        if score.quiz_id not in max_score_in_quiz or max_score_in_quiz[score.quiz_id][0] < score.total_scored:
            max_score_in_quiz[score.quiz_id] = [score.total_scored, score.total_marks]

    total_quizzes_attempted = len(max_score_in_quiz)
    total_score = sum(score[0] for score in max_score_in_quiz.values())
    total_marks = sum(score[1] for score in max_score_in_quiz.values())
    average_score = round((total_score / total_marks) * 100, 2) if total_marks > 0 else 0
    
    total_subjects = Subject.query.filter_by(status='Active').count()
    total_chapters = Chapter.query.filter_by(status='Active').count()
    total_quizzes = Quiz.query.filter_by(status='Active').count()
    
    total_subjects_attempted = Subject.query.join(Chapter, Subject.subject_id == Chapter.subject_id).join(Quiz, Chapter.chapter_id == Quiz.chapter_id).join(Score, Quiz.quiz_id == Score.quiz_id).filter(Score.user_id == user_id).count()
    total_chapters_attempted = Chapter.query.join(Quiz, Chapter.chapter_id == Quiz.chapter_id).join(Score, Quiz.quiz_id == Score.quiz_id).filter(Score.user_id == user_id).count()

    return jsonify({
        'total_quizzes_attempted': total_quizzes_attempted,
        'total_score': total_score,
        'total_marks': total_marks,
        'average_score': average_score,
        'total_subjects': total_subjects,
        'total_chapters': total_chapters,
        'total_quizzes': total_quizzes,
        'total_subjects_attempted': total_subjects_attempted,
        'total_chapters_attempted': total_chapters_attempted
    })

export_dir = 'backend/exports'

@user_bp.route('/<int:user_id>/export/csv', methods=['GET'])
@jwt_required()
def export_csv(user_id):
    if not is_user():
        return jsonify({'error': 'Access denied'}), 403
    
    task = generate_user_quiz_csv.delay(user_id)
    return jsonify({"message": "User quiz export started", "task_id": task.id}), 200

@user_bp.route('/<int:user_id>/get/csv/<task_id>', methods=['GET'])
def get_csv(user_id, task_id):
    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    task = AsyncResult(task_id)
    if task.ready():
        if task.result == "You have not attempted any quiz yet.":
            return jsonify({'message': task.result}), 200
        else:
            file_path = task.result
            return send_file(file_path, as_attachment=True), 200
    else:
        return jsonify({'message': 'Task not completed', 'status': task.status}), 405
