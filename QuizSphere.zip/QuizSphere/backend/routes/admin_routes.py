from flask import Blueprint, request, jsonify, send_file
from backend.model import db, User, Subject, Chapter, Quiz, Question, Score
from flask_jwt_extended import jwt_required, get_jwt_identity
from ..redis_celery.tasks import generate_admin_quiz_csv
from celery.result import AsyncResult
import os
from flask_caching import Cache

admin_bp = Blueprint('admin', __name__)
cache_instance = Cache()

# Helper Function to Check Admin Role
def is_admin():
    current_user = get_jwt_identity()
    return current_user.get('role') == 'Admin'

@admin_bp.route('/home', methods=['GET'])
@jwt_required()
def admin_home():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    subject_list = Subject.query.all()
    subjects = [{'subject_id': subject.subject_id, 'subject_name': subject.name, 'subject_description': subject.description, 'subject_status': subject.status} for subject in subject_list]
    joined_table = Subject.query.join(Chapter, Chapter.subject_id == Subject.subject_id).join(Quiz, Quiz.chapter_id == Chapter.chapter_id).all()
    quizzes = []
    for subject in joined_table:
        for chapter in subject.chapter:
            for quiz in chapter.quiz:
                quizzes.append({
                    'quiz_id': quiz.quiz_id,
                    'quiz_name': quiz.quiz_name,
                    'quiz_schedule': quiz.quiz_schedule,
                    'time_duration': quiz.time_duration,
                    'remarks': quiz.remarks,
                    'subject_id': subject.subject_id,
                    'subject_name': subject.name,
                    'chapter_id': chapter.chapter_id,
                    'chapter_name': chapter.name,
                    'quiz_status': quiz.status
                })
    return jsonify({'subjects': subjects, 'quizzes': quizzes}), 200

# Manage Subjects
@admin_bp.route('/add/subject', methods=['POST'])
@jwt_required()
def add_subject():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    data = request.get_json()
    subject = Subject(name=data.get('name'), description=data.get('description'), status='Active')
    db.session.add(subject)
    db.session.commit()
    return jsonify({'message': 'Subject added successfully'}), 201

@admin_bp.route('/subjects/<int:subject_id>', methods=['PUT'])
@jwt_required()
def edit_subject(subject_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404
    data = request.get_json()
    subject.name = data['name']
    subject.description = data['description']
    db.session.commit()
    return jsonify({'message': 'Subject updated successfully'})

@admin_bp.route('/toggle/subject/<int:subject_id>', methods=['PUT'])
@jwt_required()
def toggle_subject(subject_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404
    
    if subject.status=='Inactive':
        subject.status='Active'
    else:
        subject.status='Inactive'
        chapters=Chapter.query.filter_by(subject_id=subject_id).all()
        for chapter in chapters:
            chapter.status='Inactive'
            quizzes=Quiz.query.filter_by(chapter_id=chapter.chapter_id).all()
            for quiz in quizzes:
                quiz.status='Inactive'
        
    db.session.commit()
    return jsonify({'message': f'Subject marked as {subject.status}', 'subject_status': subject.status}), 200

@admin_bp.route('/home/subject/<int:subject_id>/chapters', methods=['GET'])
@jwt_required()
def get_chapters(subject_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    # Check if the subject exists
    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404

    # Retrieve all chapters related to the subject
    chapters = Chapter.query.filter_by(subject_id=subject_id).all()
    
    if not chapters:
        return jsonify({'subject_id':subject.subject_id, 'subject_name': subject.name, 'message': 'No chapters available for this subject'}), 200

    # Serialize chapter data
    chapters_list = [
        {
            'chapter_id': chapter.chapter_id,
            'chapter_name': chapter.name,
            'chapter_description': chapter.description,
            'chapter_status': chapter.status
        }
        for chapter in chapters
    ]
    
    return jsonify({'subject_id':subject.subject_id, 'subject_name': subject.name, 'chapters': chapters_list}), 200


# Manage Chapters
@admin_bp.route('/subject/<int:subject_id>/add/chapter', methods=['POST'])
@jwt_required()
def add_chapter(subject_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404
    data = request.get_json()
    chapter = Chapter(name=data['name'], description=data['description'], subject_id=subject_id, status='Active')
    db.session.add(chapter)
    db.session.commit()
    return jsonify({'message': 'Chapter added successfully'}), 201

@admin_bp.route('/chapters/<int:chapter_id>', methods=['PUT'])
@jwt_required()
def edit_chapter(chapter_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    chapter = Chapter.query.filter_by(chapter_id=chapter_id).first()
    if not chapter:
        return jsonify({'error': 'Chapter not found'}), 404
    data = request.get_json()
    chapter.name = data['name']
    chapter.description = data['description']
    db.session.commit()
    return jsonify({'message': 'Chapter updated successfully'})

@admin_bp.route('/toggle/chapter/<int:chapter_id>', methods=['PUT'])
@jwt_required()
def toggle_chapter(chapter_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    chapter = Chapter.query.filter_by(chapter_id=chapter_id).first()
    if not chapter:
        return jsonify({'error': 'Chapter not found'}), 404
    
    if chapter.status=='Inactive':
        subject=Subject.query.filter_by(subject_id=chapter.subject_id).first()
        if subject.status=='Active':
            chapter.status='Active'
        else:
            return jsonify({'error': 'Subject of this chapter is Inactive'}), 404
    else:
        chapter.status='Inactive'
        quizzes=Quiz.query.filter_by(chapter_id=chapter.chapter_id).all()
        for quiz in quizzes:
            quiz.status='Inactive'
        
    db.session.commit()
    return jsonify({'message': f'Chapter marked as {chapter.status}', 'chapter_status': chapter.status}), 200
    

# Manage Quizzes
@admin_bp.route('/subject/<int:subject_id>/chapter/<int:chapter_id>/quizzes', methods=['GET'])
@jwt_required()
def get_quizzes(subject_id, chapter_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404
    
    chapter = Chapter.query.filter_by(chapter_id=chapter_id).first()
    if not chapter:
        return jsonify({'error': 'Chapter not found'}), 404
    
    quizzes=Quiz.query.filter_by(chapter_id=chapter_id).all()
    
    if not quizzes:
        return jsonify({'subject_id':subject.subject_id, 'subject_name': subject.name, 'chapter_id':chapter.chapter_id, 'chapter_name': chapter.name, 'message': 'No quizzes available in this chapter'}), 200
    
    quiz_list= [
        {
            'quiz_id': quiz.quiz_id,
            'quiz_name': quiz.quiz_name,
            'quiz_schedule': quiz.quiz_schedule,
            'time_duration': quiz.time_duration,
            'remarks': quiz.remarks,
            'quiz_status': quiz.status
            }
        for quiz in quizzes
        ]
    
    return jsonify({'subject_id':subject.subject_id, 'subject_name': subject.name, 'chapter_id':chapter.chapter_id, 'chapter_name': chapter.name, 'quizzes': quiz_list}), 200



@admin_bp.route('/add/quiz', methods=['POST'])
@jwt_required()
def add_quiz():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    data = request.get_json()

    # Validate and get chapter_id from data
    chapter_id = data.get('chapter_id')
    
    quiz_schedule = data['quiz_schedule']
    if quiz_schedule:
        formattedSchedule = quiz_schedule.replace('T', ' ') + ':00';

        quiz_schedule=formattedSchedule
    else:
        quiz_schedule=None
    
    time_duration=data.get('time_duration')
    if time_duration:
        hours, minutes = map(int, time_duration.split(':'))
        total_minutes = hours * 60 + minutes
    else:
        total_minutes='No Time Limit'


    # Create and add the quiz
    quiz = Quiz(
        chapter_id=chapter_id,
        quiz_name=data.get('quiz_name'),
        quiz_schedule=quiz_schedule,
        time_duration=total_minutes,  # Store as HH:MM:SS string
        remarks=data.get('remarks'),
        status='Active'
    )

    db.session.add(quiz)
    db.session.commit()

    return jsonify({'message': 'Quiz added successfully'})

@admin_bp.route('/quizzes/<int:quiz_id>', methods=['PUT'])
@jwt_required()
def edit_quiz(quiz_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    quiz = Quiz.query.filter_by(quiz_id=quiz_id).first()
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    data = request.get_json()
    quiz.quiz_name = data['quiz_name']
    quiz_schedule = data['quiz_schedule']
    if quiz_schedule:
        quiz.quiz_schedule=quiz_schedule
    else:
        quiz.quiz_schedule=None
    
    time_duration = data.get('time_duration')
    if time_duration:
        hours, minutes = map(int, time_duration.split(':'))
        total_minutes = hours * 60 + minutes
        if total_minutes<1:
            total_minutes="No Time Limit"
    else:
        total_minutes = "No Time Limit"

    quiz.time_duration = total_minutes
    
    quiz.remarks = data['remarks']
    db.session.commit()
    return jsonify({'message': 'Quiz updated successfully'})



@admin_bp.route('/toggle/quiz/<int:quiz_id>', methods=['PUT'])
@jwt_required()
def toggle_quiz(quiz_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    quiz = Quiz.query.filter_by(quiz_id=quiz_id).first()
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    if quiz.status=='Inactive':
        chapter=Chapter.query.filter_by(chapter_id=quiz.chapter_id).first()
        if chapter.status=='Active':
            quiz.status='Active'
        else:
            return jsonify({'error': 'Chapter of this quiz is Inactive'}), 404
    else:
        quiz.status='Inactive'
    db.session.commit()
    return jsonify({'message': f'Quiz marked as {quiz.status}', 'quiz_status': quiz.status}), 200

# Manage Questions
@admin_bp.route('/subject/<int:subject_id>/chapter/<int:chapter_id>/quiz/<int:quiz_id>/questions', methods=['GET'])
@jwt_required()
def get_question(subject_id, chapter_id, quiz_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    subject = Subject.query.filter_by(subject_id=subject_id).first()
    if not subject:
        return jsonify({'error': 'Subject not found'}), 404
    
    chapter = Chapter.query.filter_by(chapter_id=chapter_id).first()
    if not chapter:
        return jsonify({'error': 'Chapter not found'}), 404

    quiz = Quiz.query.filter_by(quiz_id=quiz_id).first()
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    
    quiz_detail = [{ 'quiz_id':quiz.quiz_id, 'quiz_name': quiz.quiz_name, 'remarks': quiz.remarks, 'time_duration': quiz.time_duration, 'quiz_schedule': quiz.quiz_schedule}]
    
    
    questions = Question.query.filter_by(quiz_id=quiz.quiz_id).all()
    
    if not questions:
        return jsonify({
            'subject_name': subject.name,
            'chapter_name': chapter.name,
            'quiz': quiz_detail,
            'message': 'No questions available for this quiz'
                        }), 200
    
    questions_list = [
        {
            'question_id': question.question_id,
            'question_statement': question.question_statement,
            'marks': question.marks,
            'option1': question.option1,
            'option2': question.option2,
            'option3': question.option3,
            'option4': question.option4,
            'correct_option': question.correct_option,
        }
        for question in questions
    ]
    
    return jsonify({
        'subject_name': subject.name,
        'chapter_name': chapter.name,
        'quiz': quiz_detail,
        'questions': questions_list}), 200


@admin_bp.route('/quiz/<int:quiz_id>/add/question', methods=['POST'])
@jwt_required()
def add_question(quiz_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    quiz = Quiz.query.filter_by(quiz_id=quiz_id).first()
    if not quiz:
        return jsonify({'error': 'Quiz not found'}), 404
    
    data = request.get_json()
    question = Question(quiz_id=quiz_id, question_statement=data['question_statement'], marks=data['marks'], option1=data['option1'], option2=data['option2'], option3=data['option3'], option4=data['option4'], correct_option=data['correct_option'])
    db.session.add(question)
    db.session.commit()
    return jsonify({'message': 'Question added successfully'})

@admin_bp.route('/questions/<int:question_id>', methods=['PUT'])
@jwt_required()
def edit_question(question_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    question = Question.query.filter_by(question_id=question_id).first()
    if not question:
        return jsonify({'error': 'Question not found'}), 404
    data = request.get_json()
    question.question_statement = data['question_statement']
    question.marks = data['marks']
    question.option1 = data['option1']
    question.option2 = data['option2']
    question.option3 = data['option3']
    question.option4 = data['option4']
    question.correct_option = data['correct_option']
    db.session.commit()
    return jsonify({'message': 'Question updated successfully'})

@admin_bp.route('/questions/<int:question_id>', methods=['DELETE'])
@jwt_required()
def delete_question(question_id):
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403

    question = Question.query.filter_by(question_id=question_id).first()
    if not question:
        return jsonify({'error': 'Question not found'}), 404
    db.session.delete(question)
    db.session.commit()
    return jsonify({'message': 'Question deleted successfully'})

export_dir = 'backend/exports'

@admin_bp.route('/export/csv', methods=['GET'])
@jwt_required()
def export_csv():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    task = generate_admin_quiz_csv.delay()
    return jsonify({"message": "Admin quiz export started", "task_id": task.id}), 202

@admin_bp.route('/get/csv/<task_id>', methods=['GET'])
def get_csv(task_id):
    task = AsyncResult(task_id)
    if task.ready():
        file_path = task.result
        return send_file(file_path, as_attachment=True), 200
    else:
        return jsonify({'message': 'Task not completed', 'status': task.status}), 405

@admin_bp.route('/users', methods=['GET'])
@jwt_required()
def users():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    users_list = User.query.filter(User.email != 'n4nishantkumar2004@gmail.com').all()
    
    users = [ { 'user_id': user.user_id, 'email': user.email, 'full_name': user.full_name, 'qualification': user.qualification, 'dob': user.dob, 'status': user.status} for user in users_list]
    
    return jsonify({'users': users}), 200


# Route to block a user
@admin_bp.route('/users/<int:user_id>/block', methods=['PUT'])
@jwt_required()
def block_user(user_id):
    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    user.status = 'Inactive'
    db.session.commit()
    return jsonify({'message': 'User blocked successfully'}), 200

# Route to unblock a user
@admin_bp.route('/users/<int:user_id>/unblock', methods=['PUT'])
@jwt_required()
def unblock_user(user_id):
    user = User.query.filter_by(user_id=user_id).first()
    if not user:
        return jsonify({'error': 'User not found'}), 404

    user.status = 'Active'
    db.session.commit()
    return jsonify({'message': 'User unblocked successfully'}), 200

# Leaderboard
@admin_bp.route('/leaderboard', methods=['GET'])
@jwt_required()
@cache_instance.cached(timeout=60, key_prefix='admin_leaderboard_cache')
def leaderboard():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    users_list = User.query.filter(User.email != 'n4nishantkumar2004@gmail.com').all()
    
    users = [ { 'user_id': user.user_id, 'email': user.email, 'full_name': user.full_name, 'qualification': user.qualification, 'dob': user.dob, 'status': user.status} for user in users_list]
    
    score_list = Score.query.all()
    
    scores = [ { 'score_id': score.score_id, 'quiz_id': score.quiz_id, 'user_id': score.user_id, 'total_scored': score.total_scored } for score in score_list]
    
    return jsonify({ 'users': users, 'scores': scores}), 200

@admin_bp.route('/statistics', methods=['GET'])
@jwt_required()
@cache_instance.memoize(timeout=30)
def admin_statistics():
    if not is_admin():
        return jsonify({'error': 'Access denied'}), 403
    
    # Count total users
    total_users = User.query.count() - 1
    active_users = User.query.filter_by(status='Active').count() - 1
    blocked_users = total_users - active_users  
    

    # Count total subjects, chapters, and quizzes
    total_subjects = Subject.query.count()
    total_subjects_attempted = Subject.query.join(Chapter, Subject.subject_id == Chapter.subject_id).join(Quiz, Chapter.chapter_id == Quiz.chapter_id).join(Score, Quiz.quiz_id == Score.quiz_id).with_entities(Subject.subject_id).distinct().count()
    total_active_subjects = Subject.query.filter_by(status='Active').count()
    total_inactive_subjects = total_subjects - total_active_subjects
    total_chapters = Chapter.query.count()
    total_chapters_attempted = Chapter.query.join(Quiz, Chapter.chapter_id == Quiz.chapter_id).join(Score, Quiz.quiz_id == Score.quiz_id).with_entities(Chapter.chapter_id).distinct().count()
    total_active_chapters = Chapter.query.filter_by(status='Active').count()
    total_inactive_chapters = total_chapters - total_active_chapters
    total_quizzes = Quiz.query.count()
    total_quizzes_attempted = Score.query.with_entities(Score.quiz_id).distinct().count()
    total_active_quizzes = Quiz.query.filter_by(status='Active').count()
    total_inactive_quizzes = total_quizzes - total_active_quizzes
    different_users_attempted = Score.query.with_entities(Score.user_id).distinct().count()
    
    total_quizzes_have_question = Question.query.with_entities(Question.quiz_id).distinct().count()
    total_quizzes_have_no_question = total_quizzes - total_quizzes_have_question

    return jsonify({
        "total_users": total_users,
        "active_users": active_users,
        "blocked_users": blocked_users,
        "total_subjects": total_subjects,
        "total_active_subjects": total_active_subjects,
        "total_inactive_subjects": total_inactive_subjects,
        "total_subjects_attempted": total_subjects_attempted,
        "total_chapters": total_chapters,
        "total_active_chapters": total_active_chapters,
        "total_inactive_chapters": total_inactive_chapters,
        "total_chapters_attempted": total_chapters_attempted,
        "total_quizzes": total_quizzes,
        "total_active_quizzes": total_active_quizzes,
        "total_inactive_quizzes": total_inactive_quizzes,
        "total_quizzes_attempted": total_quizzes_attempted,
        "different_users_attempted": different_users_attempted,
        "total_quizzes_have_question": total_quizzes_have_question,
        "total_quizzes_have_no_question": total_quizzes_have_no_question
    }), 200