from ..main import app
from backend.model import db

with app.app_context():
    db.create_all()
