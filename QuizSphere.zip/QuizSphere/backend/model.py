from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class User(db.Model):
    __tablename__='user'
    user_id=db.Column(db.Integer, autoincrement=True, primary_key=True)
    email=db.Column(db.String(150), unique=True, nullable=False)
    password=db.Column(db.String(150), nullable=False)
    full_name=db.Column(db.String(100), nullable=False)
    role=db.Column(db.String(50), nullable=False, default='User')
    qualification=db.Column(db.String(100), nullable=False)
    dob=db.Column(db.Date, nullable=False)
    last_login=db.Column(db.DateTime)
    status=db.Column(db.String(100), nullable=False)
    
    
    score=db.relationship('Score', backref='user',lazy='dynamic', primaryjoin='User.user_id==Score.user_id')


class Subject(db.Model):
    __tablename__='subject'
    subject_id=db.Column(db.Integer, autoincrement=True, primary_key=True)
    name=db.Column(db.String(100), nullable=False)
    description=db.Column(db.String(100), nullable=False)
    status=db.Column(db.String(100), nullable=False)
    
    chapter=db.relationship('Chapter', backref='subject',lazy='dynamic', primaryjoin='Subject.subject_id==Chapter.subject_id')


class Chapter(db.Model):
    __tablename__='chapter'
    chapter_id=db.Column(db.Integer, autoincrement=True, primary_key=True)
    subject_id=db.Column(db.Integer, db.ForeignKey('subject.subject_id'), nullable=False)
    name=db.Column(db.String(100), nullable=False)
    description=db.Column(db.String(100), nullable=False)
    status=db.Column(db.String(100), nullable=False)
    
    quiz=db.relationship('Quiz', backref='Chapter',lazy='dynamic', primaryjoin='Chapter.chapter_id==Quiz.chapter_id')


class Quiz(db.Model):
    __tablename__='quiz'
    quiz_id=db.Column(db.Integer, autoincrement=True, primary_key=True)
    chapter_id=db.Column(db.Integer, db.ForeignKey('chapter.chapter_id'), nullable=False)
    quiz_name=db.Column(db.String(100), nullable=False)
    quiz_schedule=db.Column(db.String(100))
    time_duration=db.Column(db.String(50))
    remarks=db.Column(db.String(100), nullable=False)
    status=db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now())
    
    score=db.relationship('Score', backref='quiz',lazy='dynamic', primaryjoin='Quiz.quiz_id==Score.quiz_id')
    question=db.relationship('Question', backref='quiz',lazy='dynamic', primaryjoin='Quiz.quiz_id==Question.quiz_id')


class Score(db.Model):
    __tablename__='score'
    score_id=db.Column(db.Integer, autoincrement=True, primary_key=True)
    quiz_id=db.Column(db.Integer, db.ForeignKey('quiz.quiz_id'), nullable=False)
    user_id=db.Column(db.Integer, db.ForeignKey('user.user_id'), nullable=False)
    datetime_of_attempt=db.Column(db.DateTime, nullable=False)
    time_taken=db.Column(db.Integer, nullable=False)
    no_questions=db.Column(db.Integer, nullable=False)
    total_marks=db.Column(db.Integer, nullable=False)
    total_scored=db.Column(db.Integer, nullable=False)


class Question(db.Model):
    __tablename__='question'
    question_id=db.Column(db.Integer, autoincrement=True, primary_key=True)
    quiz_id=db.Column(db.Integer, db.ForeignKey('quiz.quiz_id'), nullable=False)
    question_statement=db.Column(db.String(200), nullable=False)
    marks=db.Column(db.Integer,nullable=False)
    option1=db.Column(db.String(100), nullable=False)
    option2=db.Column(db.String(100), nullable=False)
    option3=db.Column(db.String(100), nullable=False)
    option4=db.Column(db.String(100), nullable=False)
    correct_option=db.Column(db.Integer, nullable=False)
